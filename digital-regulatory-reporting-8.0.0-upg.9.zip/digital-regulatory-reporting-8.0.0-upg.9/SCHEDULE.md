# Release history

| Version   | Date      | Description                  | CDM Version | Rune Version |
|-----------|-----------|------------------------------|-----|-----|
| **DRR 1** | November 2022 | First ISDA DRR Release       | 3.0 | 4.49 |
| **DRR 2** | July 2023 | CFTC 3.1                     | 4.0 | 7.10 |
| **DRR 3** | November 2023 | EMIR Reft Preparation        | 5.0 | 9.0 |
| **DRR 4** | February 2024 | EMIR Refit & JFSA            | 5.6 | 9.6 |
| **DRR 5** | July 2024 | UK EMIR, ASIC, MAS           | 5.13 | 9.11 |
| **DRR 6** | July 2025 | CSA & HKMA                   | 5.25 | 9.58 |
| **DRR 7** | June 2026 | SEC, CDM Uplift | 6.21 | 9.83 |

# Release plans

The Release schedule is currently being identified and will then be approved by the DRR WG.  Look also at the [FINOS CDM Release Schedule](https://github.com/finos/common-domain-model/blob/master/SCHEDULE26.md) which is overseen by the FINOS CDM Steering WG.

## 2026/27 timeline

| Version                    | Description       | May | Jun | Jul | Aug | Sep | Oct | Nov | Dec | Jan 27 | Feb 27 | Mar 27 | Apr 27 |
|----------------------------|-------------------|-----|-----|-----|-----|-----|-----|-----|-----|-------|--------|--------|--------|
| **DRR 5** on CDM 5         | CFTC, EMIR, ASIC, MAS | 🟧  | ⬜  | ⬜  | ⬜  | ⬜  | ⬜  | ⬜  | ⬜  |   ⬜    |    ⬜    |    ⬜    |    ⬜    |
| **DRR 6** on CDM 5         | CSA, HKMA         | 🟩  | 🟧  | 🟧  | 🟧  | 🟧  | 🟧  | 🟧  | ⬜  | ⬜    | ⬜     | ⬜     | ⬜     |
| **DRR 7** on CDM 6         | SEC, CDM uplift   | 🟦  | 🟩  | 🟩  | 🟩  | 🟩  | 🟩  | 🟩  | 🟧  | 🟧    | 🟧     | 🟧     | 🟧     |
| **DRR 8** on CDM 6/7 (TBD) | MIFIR II   |    |   🟦  |   🟦  |   🟦  |  🟦   | 🟦  | 🟦  | 🟩  | 🟩    | 🟩     | 🟩     | 🟩     |
| **DRR 9** on CDM 7/8 (TBD) | SFTR?         |     |     |     |     |     |   |   |   |   🟦  | 🟦     | 🟦     | 🟦     |


# Release states

Release states are defined as:
* 🟦 Development – versions that include new designs from the “main” branch that are still under development.  All tests must pass but the model may continue to evolve before being released into production.
* 🟩 Production - the "latest and greatest" stable version that ideally everyone should upgrade to, and where enhancements compatible with the existing models will be included. We should aim for a release to be in Production for around a year if we can, to alleviate upgrade costs to consumers. 
* 🟧 Maintenance – when a new Production version is released then the current Production will go into Maintenance. Only critical bug fixes and changes related to critical regulatory requirements should be ported to Maintenance releases. Otherwise, functional changes would not be ported to maintenance releases.  The intention would be to have only 1 version at a time in maintenance, so each time a new Production version drops, the previous Maintenance release would go to Unsupported.
* ⬜ Unsupported/End of Life – There will be no bug fixes or other support for the version.  TBD: We may perform security scans on some more recent unsupported versions and report any identified vulnerabilities, but will not perform security remediations.

  
At any point we aim to have a maximum of one centrally supported development version, one production version and one maintenance version.

# CDM-DRR Dependency

Please see the [pom.xml](pom.xml) (Project Object Model) lines 21-27, for the current dependencies that DRR is using. 

This shows how every version of CDM links to the version of DSL (Domain-Specific Language, that supports the modelling of operational processes for the financial markets' industry), alongside the bundle version (a collection of repositories used in Rosetta).
