package org.isda.drr.example.reporting.transaction;

import com.regnosys.rosetta.common.validation.ValidationReport;
import drr.projection.dtcc.rds.harmonized.sec.rewrite.trade.functions.Project_SecPpdReportToDtccRdsHarmonized;
import drr.regulation.sec.rewrite.trade.SECTransactionReportPPD;
import drr.regulation.sec.rewrite.trade.reports.SECPPDReportFunction;
import iso20022.DtccRdsHarmonizedModelConfig;
import jakarta.inject.Inject;
import org.isda.drr.example.AbstractReportingTest;
import org.isda.drr.example.util.ReportingTestUtils;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * Test class to demonstrate SEC PPD transaction reporting with Dtcc projection.
 * This class validates the transformation of a `TransactionReportInstruction` to a `SECTransactionReportPPD`,
 * followed by validation and Dtcc projection.
 */
@Disabled

public class SECPPDTradeWithDtccProjectionTest extends AbstractReportingTest {

    // Function to generate a SEC PPD Transaction Report
    @Inject
    SECPPDReportFunction reportFunc;

    // Function to project a SEC PPD Report to Dtcc Rds Harmonized format
    @Inject
    Project_SecPpdReportToDtccRdsHarmonized secPpdReportToDtccRdsHarmonized;

    /**
     * Demonstrates SEC PPD transaction reporting with dtcc rds projection.
     * The test performs the following steps:
     * - Loads a `TransactionReportInstruction` from JSON.
     * - Generates a `SECTransactionReportPPD` and validates it.
     *
     * @throws IOException If there is an error during file reading or processing.
     */
    @Test
    void SECTradeWithDtccRdsProjectionExampleReportTest() throws IOException {

        // Generate the SEC PPD transaction report
        SECTransactionReportPPD report = runReport(transactionReportInstruction, reportFunc::evaluate);
        assertNotNull(report, "The report is null");

        // Validate the report and print validation results
        ValidationReport validationReport = validator.runProcessStep(SECTransactionReportPPD.class, report);
        ReportingTestUtils.printValidation(validationReport);

        // Project the report to Dtcc Rds Harmonized format
        projectXmlReport(report, secPpdReportToDtccRdsHarmonized::evaluate, DtccRdsHarmonizedModelConfig.XML_CONFIG_PATH);
    }
}
