package org.isda.drr.example.reporting.valuation;

import drr.projection.iso20022.jfsa.rewrite.valuation.functions.Project_JFSARewriteValuationReportToIso20022;
import drr.regulation.jfsa.rewrite.valuation.JFSAValuationReport;
import drr.regulation.jfsa.rewrite.valuation.reports.JFSAValuationReportFunction;
import iso20022.Auth030JfsaModelConfig;
import jakarta.inject.Inject;
import com.regnosys.rosetta.common.validation.ValidationReport;
import org.isda.drr.example.AbstractReportingTest;
import org.isda.drr.example.util.ReportingTestUtils;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

/**
 * Test class to demonstrate JFSA valuation reporting with ISO-20022 projection.
 * The test validates the transformation of a `ValuationReportInstruction` to a `JFSAValuationReport`,
 * followed by validation and ISO-20022 projection.
 */
@Disabled

final class JFSAValuationWithISOProjectionTest extends AbstractReportingTest {

    // Function to generate a JFSAValuationReport from a ValuationReportInstruction.
    @Inject
    JFSAValuationReportFunction reportFunc;

    // Function to project an JFSA valuation report to ISO20022 format
    @Inject
    Project_JFSARewriteValuationReportToIso20022 jfsaValuationReportToIso20022;

    /**
     * Demonstrates JFSA valuation reporting with ISO-20022 projection.
     * The test performs the following steps:
     * - Loads a `ValuationReportInstruction` from JSON.
     * - Generates an `JFSAValuationReport` and validates it.
     * - Projects the report to ISO-20022
     *
     * @throws IOException If there is an error during file reading or writing.
     */
    @Test
    void JFSAValuationWithISOProjectionExampleTest() throws IOException {

        // Generate the JFSA valuation report
        JFSAValuationReport report = runReport(valuationReportInstruction, reportFunc::evaluate);
        assertNotNull(report, "The report is null");

        // Validate the report and print validation results
        ValidationReport validationReport = validator.runProcessStep(JFSAValuationReport.class, report);
        ReportingTestUtils.printValidation(validationReport);

        // Project the report to ISO-20022 format
        projectXmlReport(report, jfsaValuationReportToIso20022::evaluate, Auth030JfsaModelConfig.XML_CONFIG_PATH);
    }
}

