package org.isda.drr.example.util;
// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)

import cdm.base.staticdata.party.metafields.ReferenceWithMetaParty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.inject.Injector;
import com.regnosys.drr.DrrRuntimeModule;
import com.regnosys.rosetta.common.serialisation.RosettaCsvMapper;
import com.regnosys.rosetta.common.serialisation.RosettaObjectMapperCreator;
import com.regnosys.rosetta.common.serialisation.fix.RuneFIXConfiguration;
import com.regnosys.rosetta.common.serialisation.fix.RuneFIXMapper;
import com.regnosys.rosetta.common.serialisation.fix.processor.RuneFIXSerializerReport;
import com.regnosys.rosetta.common.transform.LabelProviderResolver;
import com.regnosys.rosetta.common.validation.RosettaTypeValidator;
import com.regnosys.rosetta.common.validation.ValidationReport;
import com.rosetta.model.lib.RosettaModelObject;
import com.rosetta.model.lib.functions.LabelProvider;
import com.rosetta.model.lib.validation.ValidationResult;
import drr.base.trade.ReportingSide;
import drr.enrichment.common.margin.functions.Create_CollateralReportInstruction;
import drr.enrichment.common.trade.functions.Create_TransactionReportInstruction;
import drr.enrichment.common.valuation.functions.Create_ValuationReportInstruction;
import drr.regulation.common.*;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import quickfix.ConfigError;
import quickfix.DataDictionary;

import java.io.IOException;
import java.net.URL;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Utility class for testing reporting processes in the DRR (Data Reporting Repository).
 * Provides helper methods for validation, reporting side creation, and ISO-20022 XML generation.
 */
public class ReportingTestUtils {

    private static final Logger logger = LoggerFactory.getLogger(ReportingTestUtils.class);

    // Injected functions for creating transaction, collateral, and valuation report instructions
    @Inject
    protected Create_TransactionReportInstruction createTransactionReportInstructionFunc;

    @Inject
    protected Create_CollateralReportInstruction createCollateralReportInstructionFunc;

    @Inject
    protected Create_ValuationReportInstruction createValuationReportInstruction;

    // Validator for running validation processes
    @Inject
    protected RosettaTypeValidator validator;

    // Static injector and runtime module
    protected static Injector injector;
    protected static DrrRuntimeModule drrRuntimeModule = new DrrRuntimeModule();

    /**
     * Prints a validation report to the console.
     * Errors are displayed first, followed by successful results.
     *
     * @param validationReport The validation report to be printed.
     * @param <T>              Type of the Rosetta model object being validated.
     */
    public static <T extends RosettaModelObject> void printValidation(ValidationReport validationReport) {
        logger.debug(String.format("\n\n+-------------------+\n| %s |\n+-------------------+%n", "Report Validation"));

        // Sort and print validation results: errors first, then successes.
        validationReport.getValidationResults().stream()
                .sorted(Comparator.comparing(ValidationResult::isSuccess, Boolean::compareTo))
                .map(ValidationResult::toString)
                .forEach(logger::debug);
    }

    /**
     * Creates a default reporting side from a reportable event by extracting distinct party references.
     *
     * @param reportableEvent The reportable event.
     * @param <T>             Type of the Rosetta model object.
     * @return A ReportingSide object representing the reporting party and counterparty.
     */
    public static <T extends RosettaModelObject> ReportingSide createDefaultReportingSideFromReportableEvent(ReportableEvent reportableEvent) {
        // Extract distinct party references
        List<ReferenceWithMetaParty> parties = reportableEvent.getReportableInformation()
                .getJurisdictionInformation()
                .stream()
                .map(ReportableJurisdictionInformation::getPartyInformation)
                .flatMap(List::stream)
                .map(JurisdictionPartyInformation::getPartyReference)
                .distinct()
                .collect(Collectors.toList());

        // Assume the first two parties are reporting party and counterparty
        ReferenceWithMetaParty party1 = parties.get(0);
        ReferenceWithMetaParty party2 = parties.get(1);

        // Build and return the ReportingSide
        return ReportingSide.builder()
                .setReportingParty(party1)
                .setReportingCounterparty(party2)
                .build();
    }

    /**
     * Creates a default reporting side from a reportable collateral by extracting distinct party references.
     *
     * @param reportableCollateral The reportable collateral.
     * @param <T>                  Type of the Rosetta model object.
     * @return A ReportingSide object representing the reporting party and counterparty.
     */
    public static <T extends RosettaModelObject> ReportingSide createDefaultReportingSideFromReportableCollateral(ReportableCollateral reportableCollateral) {
        List<ReferenceWithMetaParty> parties = reportableCollateral.getReportableInformation()
                .getJurisdictionInformation()
                .stream()
                .map(ReportableJurisdictionInformation::getPartyInformation)
                .flatMap(List::stream)
                .map(JurisdictionPartyInformation::getPartyReference)
                .distinct()
                .collect(Collectors.toList());

        ReferenceWithMetaParty party1 = parties.get(0);
        ReferenceWithMetaParty party2 = parties.get(1);

        return ReportingSide.builder()
                .setReportingParty(party1)
                .setReportingCounterparty(party2)
                .build();
    }

    /**
     * Creates a default reporting side from a reportable valuation by extracting distinct party references.
     *
     * @param reportableValuation The reportable valuation.
     * @param <T>                 Type of the Rosetta model object.
     * @return A ReportingSide object representing the reporting party and counterparty.
     */
    public static <T extends RosettaModelObject> ReportingSide createDefaultReportingSideFromReportableValuation(ReportableValuation reportableValuation) {
        List<ReferenceWithMetaParty> parties = reportableValuation.getReportableInformation()
                .getJurisdictionInformation()
                .stream()
                .map(ReportableJurisdictionInformation::getPartyInformation)
                .flatMap(List::stream)
                .map(JurisdictionPartyInformation::getPartyReference)
                .distinct()
                .collect(Collectors.toList());

        ReferenceWithMetaParty party1 = parties.get(0);
        ReferenceWithMetaParty party2 = parties.get(1);

        return ReportingSide.builder()
                .setReportingParty(party1)
                .setReportingCounterparty(party2)
                .build();
    }

    /**
     * Generates XML output for a given document using a specified configuration.
     *
     * @param document  The Rosetta model object to be serialized.
     * @param xmlConfig The URL to the XML configuration.
     * @throws IOException If an error occurs while reading the configuration or writing the output.
     */
    public static void logXMLProjection(RosettaModelObject document, URL xmlConfig) throws IOException {
        logger.debug("XML mapper config path: {}", xmlConfig);

        // Create an XML object mapper using the provided configuration
        ObjectMapper objectMapper = RosettaObjectMapperCreator.forXML(xmlConfig.openStream()).create();

        // Serialize the document to XML and print it with pretty formatting
        logger.info("\n\n+-------------------+\n|     {}     |\n+-------------------+\n{}",
                "XML Report",
                objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(document)
        );
    }

    /**
     * Generates CSV output for a given document using a specified configuration.
     *
     * @param document  The Rosetta model object to be serialized.
     * @throws IOException If an error occurs while reading the configuration or writing the output.
     */
    public static void logCSVProjection(RosettaModelObject document, Class projectionClass) throws IOException {

        // Create the labelProvider using the projection class
        LabelProvider labelProvider = LabelProviderResolver.fromTransformFunction(projectionClass);

        // Create the CSV mapper using the label provider
        RosettaCsvMapper csvMapper = RosettaCsvMapper.createCsvObjectMapper(labelProvider);

        // Serialize the document to CSV and print it with pretty formatting
        logger.info("\n\n+-------------------+\n|     {}     |\n+-------------------+\n{}",
                "CSV Report",
                csvMapper.writerWithDefaultPrettyPrinter().writeValueAsString(document)
        );
    }
	
	public static void logFIXProjection(RosettaModelObject document, URL fixConfig) throws IOException, ConfigError {

        RuneFIXConfiguration configuration = RuneFIXConfiguration.load(fixConfig.openStream());
        DataDictionary dictionary = new DataDictionary(configuration.getDictionaryPath());
        RuneFIXMapper fixMapper = RuneFIXMapper.createFIXMapper(configuration, dictionary);

        RuneFIXSerializerReport report = fixMapper.writeValueAsFIXReport(document, true);
        if (report.hasErrors()) {
            String validationErrors = report.getErrors().stream()
                    .map(issue -> String.format(
                            "[%s] path='%s': %s",
                            issue.getCode(),
                            issue.getPath(),
                            issue.getMessage())
                    )
                    .collect(Collectors.joining(System.lineSeparator()));

            logger.debug("FIX projection validation reported {} error(s):{}{}",
                    report.getErrors().size(),
                    System.lineSeparator(),
                    validationErrors);
        } else {
            logger.debug("FIX projection validation passed.");
        }

        logger.info("\n\n+-------------------+\n|     {}     |\n+-------------------+\n{}",
                "FIX Report",
                report.getFixMessage().toString().replace('\u0001', '|')
        );
    }
}
