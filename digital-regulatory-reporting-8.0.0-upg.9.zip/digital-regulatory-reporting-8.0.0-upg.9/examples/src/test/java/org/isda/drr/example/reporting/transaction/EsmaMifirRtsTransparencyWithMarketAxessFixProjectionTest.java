//package org.isda.drr.example.reporting.transaction;
//
//import com.regnosys.rosetta.common.validation.ValidationReport;
//import drr.projection.marketaxess.esma.mifir.rewrite.transparency.functions.Project_EsmaMifirRts1TransparencyReportToMarketAxessFix;
//import drr.projection.marketaxess.esma.mifir.rewrite.transparency.functions.Project_EsmaMifirRts2TransparencyReportToMarketAxessFix;
//import drr.regulation.esma.mifir.rewrite.transparency.rts1.MIFIRTransparencyReportRTS1;
//import drr.regulation.esma.mifir.rewrite.transparency.rts1.reports.ESMAMIFIRRTS1ReportFunction;
//import drr.regulation.esma.mifir.rewrite.transparency.rts2.MIFIRTransparencyReportRTS2;
//import drr.regulation.esma.mifir.rewrite.transparency.rts2.reports.ESMAMIFIRRTS2ReportFunction;
//import jakarta.inject.Inject;
//import org.isda.drr.example.AbstractReportingTest;
//import org.isda.drr.example.util.ReportingTestUtils;
//import org.junit.jupiter.api.Test;
//import quickfix.ConfigError;
//
//import java.io.IOException;
//
//import static fix.FIX50SP2MarketAxessMiFIRModelConfig.FIX_CONFIG_PATH;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
///**
// * Test class to demonstrate ESMA MIFIR RTS 2 transparency reporting with FIX projection.
// * This class validates the transformation of an instruction to a `MIFIRTransparencyReportRTS2`,
// * followed by validation and MarketAxess APA FIX projection.
// */
//class EsmaMifirRtsTransparencyWithMarketAxessFixProjectionTest extends AbstractReportingTest {
//
//    // Function to generate an ESMA MIFIR RTS 2 Transparency Report
//    @Inject
//    ESMAMIFIRRTS2ReportFunction rts2ReportFunc;
//
//    @Inject
//    ESMAMIFIRRTS1ReportFunction rts1ReportFunc;
//
//    // Function to project a MIFIR Transparency Report to FIX format
//    @Inject
//    Project_EsmaMifirRts2TransparencyReportToMarketAxessFix esmaMifirRts2TransparencyReportToMarketAxessFix;
//
//    @Inject
//    Project_EsmaMifirRts1TransparencyReportToMarketAxessFix esmaMifirRts1TransparencyReportToMarketAxessFix;
//
//    /**
//     * Demonstrates MIFIR RTS2 Transparency reporting with MarketAxess FIX projection.
//     * The test performs the following steps:
//     * - Loads a report instruction from JSON.
//     * - Generates a `MIFIRTransparencyReportRTS2` and validates it.
//     * - Projects the report to a FIX string payload.
//     *
//     * @throws IOException If there is an error during file reading or processing.
//     * @throws ConfigError If the QuickFIX/J DataDictionary fails to load.
//     */
//    @Test
//    void MIFIRRTS2TransparencyWithFIXProjectionExampleTest() throws IOException, ConfigError {
//
//        // Generate the MIFIR transparency report
//        MIFIRTransparencyReportRTS2 report = runReport(transactionReportInstruction, rts2ReportFunc::evaluate);
//        assertNotNull(report, "The report is null");
//
//        // Validate the report and print validation results
//        ValidationReport validationReport = validator.runProcessStep(MIFIRTransparencyReportRTS2.class, report);
//        ReportingTestUtils.printValidation(validationReport);
//
//        // Project the report to FIX format
//        projectFIXReport(report, esmaMifirRts2TransparencyReportToMarketAxessFix::evaluate, FIX_CONFIG_PATH);
//    }
//
//    /**
//     * Demonstrates MIFIR RTS1 Transparency reporting with MarketAxess FIX projection.
//     * The test performs the following steps:
//     * - Loads a report instruction from JSON.
//     * - Generates a `MIFIRTransparencyReportRTS1` and validates it.
//     * - Projects the report to a FIX string payload.
//     *
//     * @throws IOException If there is an error during file reading or processing.
//     * @throws ConfigError If the QuickFIX/J DataDictionary fails to load.
//     */
//    @Test
//    void MIFIRRTS1TransparencyWithFIXProjectionExampleTest() throws IOException, ConfigError {
//
//        // Generate the MIFIR transparency report
//        MIFIRTransparencyReportRTS1 report = runReport(transactionReportInstruction, rts1ReportFunc::evaluate);
//        assertNotNull(report, "The report is null");
//
//        // Validate the report and print validation results
//        ValidationReport validationReport = validator.runProcessStep(MIFIRTransparencyReportRTS1.class, report);
//        ReportingTestUtils.printValidation(validationReport);
//
//        // Project the report to FIX format
//        projectFIXReport(report, esmaMifirRts1TransparencyReportToMarketAxessFix::evaluate, FIX_CONFIG_PATH);
//    }
//}
