/*
package org.isda.drr.example.reporting.transaction;

import com.regnosys.rosetta.common.validation.ValidationReport;
import drr.projection.unavista.esma.mifir.rewrite.trade.functions.Project_EsmaMifirTradeReportToUnavistaCSV;
import drr.regulation.esma.mifir.rewrite.trade.MIFIRTransactionReportRTS22;
import drr.regulation.esma.mifir.rewrite.trade.reports.ESMAMIFIRRTS22ReportFunction;
import jakarta.inject.Inject;
import org.isda.drr.example.AbstractReportingTest;
import org.isda.drr.example.util.ReportingTestUtils;
import org.junit.jupiter.api.Test;

import java.io.IOException;

import static org.junit.jupiter.api.Assertions.assertNotNull;

*/
/**
 * Test class to demonstrate ESMA MIFIR RTS22 trade reporting with CSV projection.
 * This class validates the transformation of a `TransactionReportInstruction` to a `MIFIRTransactionReport`,
 * followed by validation and Unavista CSV projection.
 *//*

public class MIFIRRTS22TradeWithUnavistaCsvProjectionTest extends AbstractReportingTest {

    // Function to generate an ESMA MIFIR RTS 22 Trade Report from a TransactionReportInstruction
    @Inject
    ESMAMIFIRRTS22ReportFunction reportFunc;

    // Function to project a MIFIR Trade Report to CSV format
    @Inject
    Project_EsmaMifirTradeReportToUnavistaCSV esmaMifirTradeReportToUnavistaCSV;

    */
/**
     * Demonstrates MIFIR trade reporting with Unavista CSV projection.
     * The test performs the following steps:
     * - Loads a `TransactionReportInstruction` from JSON.
     * - Generates a `ESMAMIFIRTransactionReport` and validates it.
     * - Projects the report to CSV format.
     *
     * @throws IOException If there is an error during file reading or processing.
     *//*

    @Test
    void MIFIRTradeWithCSVProjectionExampleTest() throws IOException {

        // Generate the MIFIR transaction report
        MIFIRTransactionReportRTS22 report = runReport(transactionReportInstruction, reportFunc::evaluate);
        assertNotNull(report, "The report is null");

        // Validate the report and print validation results
        ValidationReport validationReport = validator.runProcessStep(MIFIRTransactionReportRTS22.class, report);
        ReportingTestUtils.printValidation(validationReport);

        // Project the report to CSV format
        projectCsvReport(report, esmaMifirTradeReportToUnavistaCSV::evaluate, Project_EsmaMifirTradeReportToUnavistaCSV.class);
    }
}
*/
