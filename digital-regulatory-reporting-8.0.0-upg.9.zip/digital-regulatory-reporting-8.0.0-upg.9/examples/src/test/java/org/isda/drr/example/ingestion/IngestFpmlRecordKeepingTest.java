package org.isda.drr.example.ingestion;
// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.Resources;
import com.regnosys.rosetta.common.serialisation.RosettaObjectMapper;
import drr.regulation.common.ReportableEvent;
import fpml.consolidated.doc.Document;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.net.URL;

import static org.junit.jupiter.api.Assertions.assertNotNull;


/**
 * Integration-style test that manually runs the FpML -> ReportableEvent ingestion
 * using Rosetta XML ObjectMapper (configured via xml-config)
 */
public class IngestFpmlRecordKeepingTest extends AbstractIngestionTest {

    private static final Logger logger = LoggerFactory.getLogger(IngestFpmlRecordKeepingTest.class);
    ObjectMapper mapper = RosettaObjectMapper.getNewRosettaObjectMapper();

    /**
     * Tests the ingestion of an FpML recordKeeping XML file into a ReportableEvent object.
     * This verifies that the XML configuration is correctly loaded, the document is parsed,
     * and the ingestion function produces a valid ReportableEvent.
     *
     * @throws IOException if the XML file cannot be read
     */
    @Test
    void ingestFpmlRecordKeepingToReportableEvent() throws IOException {

        // Load a specific FpML file
        URL url = Resources.getResource("ingest/input/cftc-event-scenarios/Example-01-Submission-1.xml");
        Document document = defaultXmlMapper.readValue(url, Document.class);

        // Log the fpml document
        logger.debug(defaultXmlWriter.writeValueAsString(document));

        // Evaluate the function
        ReportableEvent reportableEvent = fpmlRecordKeepingToReportableEvent.evaluate(document);
        assertNotNull(reportableEvent, "ReportableEvent is null");

        // Log the resulting reportableEvent
        logger.debug(mapper.writerWithDefaultPrettyPrinter().writeValueAsString(reportableEvent));
    }
}

