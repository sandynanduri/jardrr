# Website

This website is built using [Docusaurus](https://docusaurus.io/), a modern static website generator.

## Installation

```bash
yarn
```

## Local Development

```bash
yarn start
```

This command starts a local development server and opens up a browser window. Most changes are reflected live without having to restart the server.

## Build

```bash
npm run build
```

This command generates static content into the `build` directory. It also attempts to generate a PDF version of the documentation (if the production site is reachable) and includes it in the build output.

## PDF Generation

To see the "Download PDF" link work during local development (`npm start`), you must first generate the PDF manually:

```bash
npm run build:pdf
```

The PDF will be saved to `static/DRR_Documentation.pdf` and will be served by the development server.

When running `npm run build`, the PDF is automatically generated and included in the final output.

## Deployment

Using SSH:

```bash
USE_SSH=true yarn deploy
```

Not using SSH:

```bash
GIT_USER=<Your GitHub username> yarn deploy
```

If you are using GitHub pages for hosting, this command is a convenient way to build the website and push to the `gh-pages` branch.
