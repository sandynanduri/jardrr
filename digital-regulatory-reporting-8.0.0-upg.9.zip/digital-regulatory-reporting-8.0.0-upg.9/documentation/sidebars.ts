import type {SidebarsConfig} from '@docusaurus/plugin-content-docs';

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

/**
 * Creating a sidebar enables you to:
 - create an ordered group of docs
 - render a sidebar for each doc of that group
 - provide next/previous navigation

 The sidebars can be generated from the filesystem, or explicitly defined here.

 Create as many sidebars as you want.
 */
const sidebars: SidebarsConfig = {
  tutorialSidebar: [
    {
      type: 'doc',
      id: 'README',
      label: 'Overview',
      customProps: {
        icon: '/img/drr/isda_logo.svg',
      },
    },
    {
      type: 'category',
      label: 'Introduction',
      link: {
        type: 'doc',
        id: 'introduction/introduction',
      },
      items: [],
      customProps: {
        icon: '/img/drr/drr_logo.png',
      },
    },
    {
      type: 'category',
      label: 'Get started',
      link: {type: 'doc', id: 'get-started/get-started'},
      items: [
        'get-started/pre-req',
        'get-started/introducing-drr',
        'get-started/how-drr-works',
        'get-started/drr-and-cdm',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-get-started.svg',
      },
    },
    {
      type: 'category',
      label: 'Using DRR',
      link: {type: 'doc', id: 'using-drr/using-drr'},
      items: [
        'using-drr/scope-and-structure',
        'using-drr/drr-namespace-structure',
        'using-drr/core-modelling-components',
        {
          type: 'doc',
          id: 'using-drr/drr-design-principles',
          label: 'DRR design principles',
        },
        'using-drr/implement-drr',
        'using-drr/fpml-ingest',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-using-drr.svg',
      },
    },
    {
      type: 'category',
      label: 'Tutorials',
      link: {type: 'doc', id: 'tutorials/tutorials'},
      items: [
        'tutorials/drr-data-journey-using-rosetta',
        'tutorials/drr-data-journey-using-an-ide',
        'tutorials/drr-data-journey-via-api',
        'tutorials/create-a-new-regime',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-tutorials.svg',
      },
    },
    {
      type: 'category',
      label: 'For developers',
      link: {type: 'doc', id: 'for-developers/for-developers'},
      items: [
        'for-developers/key-concepts',
        'for-developers/adding-a-new-jurisdiction',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-efficient.svg',
      },
    },
    {
      type: 'doc',
      id: 'reference-guides-drr/reference-guides',
      label: 'Reference guides',
      customProps: {
        icon: '/img/drr/drr-icon-reference-guides.svg',
      },
    },
    {
      type: 'category',
      label: 'Resources',
      link: {type: 'doc', id: 'resources/resources'},
      items: [
        'resources/faqs',
        {type: 'link', label: 'Glossary', href: '/docs/resources/glossary'},
      ],
      customProps: {
        icon: '/img/drr/drr-icon-resources.svg',
      },
    },
    {
      type: 'category',
      label: 'Governance',
      link: {type: 'doc', id: 'governance/governance'},
      items: [
        'governance/development-roadmap-governance-and-process',
        'governance/working-group-terms-of-reference',
        'governance/drr-community-roadmap',
        'governance/governance-guidelines',
        'governance/maintenance-and-release',
        'governance/versioning',
        'using-drr/drr-design-principles',
        'governance/contributing-workflow',
        'governance/change-control-guidelines',
        'governance/editing',
        'governance/release-schedule',
        'governance/major-release-scheduling-guidelines',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-governance.svg',
      },
    },
    {
      type: 'category',
      label: 'Get involved',
      link: {type: 'doc', id: 'get-involved/get-involved'},
      items: [
        'get-involved/contribute-to-drr-documentation',
        'get-involved/contribute-to-drr/contribute-to-drr',
      ],
      customProps: {
        icon: '/img/drr/drr-icon-get-involved.svg',
      },
    },
  ],
};

export default sidebars;
