import React, { type ReactNode } from 'react';

interface CalloutProps {
  title?: string;
  children: ReactNode;
}

export default function Callout({ title = 'Note', children }: CalloutProps): ReactNode {
  return (
    <div className="callout-card">
      <div className="callout-card-title">
        <span>💡</span> {title}
      </div>
      <div className="callout-card-content">
        {children}
      </div>
    </div>
  );
}
