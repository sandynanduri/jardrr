import React from 'react';
import Link from '@docusaurus/Link';
import useBaseUrl from '@docusaurus/useBaseUrl';
import styles from './styles.module.css';

interface CardProps {
  title: string;
  description: string;
  to: string;
  icon?: string;
}

const Card: React.FC<CardProps> = ({ title, description, to, icon }) => {
  return (
    <Link to={to} className={styles.card}>
      {icon && (
        <div className={styles.iconContainer}>
          <img src={useBaseUrl(icon)} alt={`${title} icon`} className={styles.icon} />
        </div>
      )}
      <div className={styles.cardContent}>
        <h3 className={styles.title}>{title}</h3>
        <p className={styles.description}>{description}</p>
      </div>
    </Link>
  );
};

export default Card;
