import type {ReactNode} from 'react';
import clsx from 'clsx';
import Heading from '@theme/Heading';
import styles from './styles.module.css';

type FeatureItem = {
  title: string;
  imgSrc: string;
  imgAlt?: string;
  description: ReactNode;
};

const FeatureList: FeatureItem[] = [
  {
    title: 'Consistent',
    imgSrc: require('@site/static/img/drr/drr-icon-consistent.svg').default,
    imgAlt: 'Consistent',
    description: (
      <>
        DRR follows a common set of design principles and a unified modelling guide.
        This helps everyone interpret and apply the rules in the same way, ensuring reporting is aligned with industry best practice.
      </>
    ),
  },
  {
    title: 'Transparent',
    imgSrc: require('@site/static/img/drr/drr-icon-efficient.svg').default,
    imgAlt: 'Transparent',
    description: (
      <>
        The scope and status of each reporting requirement is clearly defined,
        and every data point can be traced back to its source. This makes it easier to understand how and why a reporting decision was made.
      </>
    ),
  },
  {
    title: 'Efficient',
    imgSrc: require('@site/static/img/drr/drr-icon-transparent.svg').default,
    imgAlt: 'Efficient',
    description: (
      <>
        DRR streamlines the journey from raw trade data to a complete regulatory report.
        By automating the logic, it reduces manual effort and lowers the risk of errors.
      </>
    ),
  },
];

function Feature({title, imgSrc, imgAlt, description}: FeatureItem) {
  return (
    <div className={clsx('col col--4')}>
      <div className="text--center">
        <img className={styles.featureSvg} src={imgSrc} alt={imgAlt ?? title} role="img" />
      </div>
      <div className="text--center padding-horiz--md">
        <Heading as="h3">{title}</Heading>
        <p>{description}</p>
      </div>
    </div>
  );
}

export default function HomepageFeatures(): ReactNode {
  return (
    <section className={styles.features}>
      <div className="container">
        <div className="row">
          {FeatureList.map((props, idx) => (
            <Feature key={idx} {...props} />
          ))}
        </div>
      </div>
    </section>
  );
}
