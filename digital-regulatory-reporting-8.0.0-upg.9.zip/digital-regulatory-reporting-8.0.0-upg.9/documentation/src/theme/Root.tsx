import React, {useEffect} from 'react';
import mediumZoom from 'medium-zoom';
import {useLocation} from '@docusaurus/router';
import ExecutionEnvironment from '@docusaurus/ExecutionEnvironment';

export default function Root({children}: {children: React.ReactNode}) {
  const location = useLocation();

  useEffect(() => {
    if (ExecutionEnvironment.canUseDOM) {
      // Small delay to ensure images are in the DOM
      setTimeout(() => {
        mediumZoom('article img', {
          margin: 24,
          background: 'rgba(0,0,0,0.9)',
        });
      }, 500);
    }
  }, [location.pathname]);

  return <>{children}</>;
}
