import React, {type ReactNode} from 'react';
import Layout from '@theme-original/DocItem/Layout';
import type LayoutType from '@theme/DocItem/Layout';
import type {WrapperProps} from '@docusaurus/types';
import {useDoc} from '@docusaurus/plugin-content-docs/client';

type Props = WrapperProps<typeof LayoutType>;

export default function LayoutWrapper(props: Props): ReactNode {
  const {metadata} = useDoc();
  const {lastUpdatedAt, lastUpdatedBy} = metadata ?? {};

  return (
    <div style={{position: 'relative'}}>
      {metadata && (lastUpdatedAt || lastUpdatedBy) && (
        <div className="last-updated-top" style={{
          position: 'absolute',
          top: '0.5rem',
          right: '0',
          fontSize: '0.75rem',
          color: 'var(--ifm-color-emphasis-600)',
          fontStyle: 'italic'
        }}>
          {lastUpdatedAt && (
             <span>Last updated on {new Date((lastUpdatedAt as any)?.date || (lastUpdatedAt as any) * 1000).toLocaleDateString()}</span>
          )}
          {lastUpdatedBy && (
             <span> by {lastUpdatedBy}</span>
          )}
        </div>
      )}
      <Layout {...props} />
    </div>
  );
}
