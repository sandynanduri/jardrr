import React, {type ReactNode} from 'react';
import Layout from '@theme-original/Layout';
import type LayoutType from '@theme/Layout';
import type {WrapperProps} from '@docusaurus/types';
import {useLocation} from '@docusaurus/router';
import Link from '@docusaurus/Link';

type Props = WrapperProps<typeof LayoutType>;

export default function LayoutWrapper(props: Props): ReactNode {
  const {pathname} = useLocation();
  // Check if we are on the glossary page
  const isGlossaryPage = pathname.includes('/docs/resources/glossary');
  const {children, ...rest} = props;

  return (
    <Layout {...rest}>
      {isGlossaryPage && (
        <div className="container margin-top--md">
          <Link 
            to="/docs/resources" 
            className="button button--secondary button--outline margin-bottom--sm"
            style={{
              display: 'inline-flex', 
              alignItems: 'center', 
              gap: '0.5rem',
              fontWeight: 600,
              borderRadius: '8px',
              padding: '0.4rem 0.8rem',
              border: '1px solid #e2e8f0',
              backgroundColor: 'var(--ifm-background-color)',
            }}>
            <span style={{fontSize: '1.2rem', lineHeight: 1}}>←</span> Back to Resources
          </Link>
        </div>
      )}
      {children}
    </Layout>
  );
}
