import {type ReactNode, useEffect} from 'react';
import clsx from 'clsx';
import Link from '@docusaurus/Link';
import useDocusaurusContext from '@docusaurus/useDocusaurusContext';
import Layout from '@theme/Layout';
import HomepageFeatures from '@site/src/components/HomepageFeatures';

import styles from './index.module.css';

// Hide search bar on homepage
function useHideSearchBar() {
  useEffect(() => {
    const searchBar = document.querySelector('.navbar__search') as HTMLElement;
    if (searchBar) {
      searchBar.style.display = 'none';
    }
    return () => {
      if (searchBar) {
        searchBar.style.display = '';
      }
    };
  }, []);
}

function HomepageHeader() {
  const {siteConfig} = useDocusaurusContext();
  return (
    <header className={styles.heroBanner}>
      <div className="container">
        <div className="row">
          <div className={clsx('col col--6', styles.heroText)}>
            <img 
              src={require('../../static/img/drr/DRR-logo.png').default}
              alt="ISDA Digital Regulatory Reporting" 
              className={styles.heroLogo}
            />
            <p className="hero__subtitle">{siteConfig.tagline}</p>
            <div className={styles.buttons}>
              <Link
                className={clsx('button button--lg', styles.primaryBtn)}
                to="/docs/introduction">
                Docs
              </Link>
            </div>
          </div>
          <div className={clsx('col col--6', styles.heroVideoCol)}>
            <div className={styles.videoContainer}>
              <iframe
                width="100%"
                height="280"
                src="https://www.youtube.com/embed/RrCL0yCz-0s"
                title="Introduction to ISDA's Digital Regulatory Reporting Initiative"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                referrerPolicy="strict-origin-when-cross-origin"
                allowFullScreen>
              </iframe>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}

export default function Home(): ReactNode {
  const {siteConfig} = useDocusaurusContext();
  useHideSearchBar();
  return (
    <Layout
      title={siteConfig.title}
      description="Digital Regulatory Reporting documentation">
      <HomepageHeader />
      <main>
        <HomepageFeatures />
      </main>
    </Layout>
  );
}
