---
title: DRR development design principles
sidebar_label: DRR development design principles
sidebar_position: 3
description: The principles we follow when developing the model.
---



# DRR development design principles

The DRR model is built as an extension of the Common Domain Model (CDM). DRR uses the CDM to represent trades and lifecycle events as a required input for the DRR process. In practice, this means that DRR adheres to the same design principles as the CDM, while adapting them to meet the specific requirements of regulatory reporting. In this context, these principles can be summarised into four key design principles:

- Functional
- Composable and reusable
- Auditable
- Test-driven

## Functional
The DRR model contains a complete set of logical instructions to take a CDM input and produce a regulator-ready output. There is no hidden or behind-the-scene logic that an implementor would need, in addition to the one expressed in the model, to build that reporting system. If that implementation uses the model’s auto-generated executable code, no further code is required to express the reporting logic - although some coding is necessary to integrate what the DRR model provides. 

This feature is key to ensuring the consistency and comparability of reported data across the market, i.e. the same inputs would produce the same reporting output regardless of the particularities of each firm’s implementation.

## Composable and reusable
The DRR model is built on defining reusable components, which helps prevent repeating logic and duplication of effort. 

The DRR function `TradeForEvent` demonstrates this approach in practice. As reporting logic starts from a transaction event, many reportable fields require access to the associated details of a trade. Rather than embedding trade retrieval logic inside every reporting rule, **DRR defines this logic once** in `TradeForEvent`, and resues it where required.

```
reporting rule NotionalQuantityLeg1 from TransactionReportInstruction: <"Notional Quantity Leg 1">
    filter IsAllowableActionForCFTC
    then if IsEquity(ProductForTrade(TradeForEvent)) = False
        then common.quantity.NotionalQuantityLeg1
```

## Auditable
Every reporting rule defined in the DRR model can be directly linked back to the regulatory text that it comes from. The model allows for precise references to documents and provisions contained within those documements. This is implemented in DRR using the [**document reference**](https://rune-docs.netlify.app/docs/modelling-components/metadata#2-document-reference) feature of the Rune DSL. 

```
reporting rule Cleared from TransactionReportInstructionBase: <"Cleared">
    [regulatoryReference CPMI_IOSCO cdeV3.CDE section "2" field "14"
        provision "Indicator of whether the transaction has been cleared, or is intended to be cleared, by a central counterparty."]
```

## Test-driven

DRR uses a test-driven approach to develop the reporting model. This means that the model is being systematically tested using transaction data inputs, and the reported outputs are validated against an expected result.

The transaction data inputs are synthetic data - i.e. not actual production data but data that are representative of real-life transaction scenarios and that can be used to test the validity of the reporting logic. They are typically provided by firms participating in DRR, after those firms apply suitable anonymisation and data scrambling to preserve privacy. A reporting rule is considered fully developed only once its logic has been verified against relevant test data.

Test data is organised around themes and grouped into _Test Packs_ in the DRR model repository - for instance, by asset class. Each test pack contains both the transaction data inputs and their expected output. Test packs are an integral part of the model and are readily available to allow firms to benchmark their own implementations. 

This approach supports the ongoing governance of the DRR model. Any mismatch in the pre-loaded test packs would generate expectation differences which need to either be resolved, or explained if the change is justified.



