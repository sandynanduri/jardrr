---
title: DRR namespace structure
sidebar_label: DRR namespace structure
sidebar_position: 2
description: How the data in DRR is organized.
---


## DRR namespace structure

**Digital Regulatory Reporting** is layered and modular by design. The DRR model follows the CDM's organising principles into namespaces.

 
- **Base:** The _Base_ namespace leverages elements defined in the CDM. It contains the core, reusable building blocks that underpin the entire DRR model. 
 
- **Enrichment:** The _Enrichment_ namespace defines types, functions and rules that enrich DRR objects with the information required for regulatory reporting. Within this namespace, a trade can be enriched from a `ReportableEvent` into a `TransactionReportInstruction`, for example, adding elements such as `ReportableInfomation` and `ReportingSide`.
   

- **Ingest:** The _Ingest_ namespace contains the functional mappings for FpML Record Keeping trade messages. This namespace details the elements required to ingest a `FpML NonPublicExecutionReport` message and transform it directly into a `ReportableEvent`.


- **Standards:** The _Standards_ namespace defines and codifies the Critical Data Elements or CDEs of regulatory reporting. Critical Data Elements are standardised, well-defined data fields that are used consistently across regulatory reporting frameworks. They ensure that different firms and regulators interoperate and report the same information the same way. CDEs are the building blocks for regulatory reports.
 

- **Regulation:** The _Regulation_ namespace of DRR contains the reporting-specific logic, where regulatory text is digitised and translated into code. Reporting rules and their interperations include references to the relevant regulatory text and where applicable, the outcomes of the working group discussions. Within this namespace, sub-namespaces are organised by regulation name, along with a _Common_ namespace. This houses shared rules and regulatory logic that apply across multiple regulatory regimes to ensure consistency and reuse throughout the DRR framework.
  
- **Projection:** The _Projection_ namespace contains elements necessary to transform DRR report output into a report file formatted for submission to trade repositories and regulators. This layer of the DRR structure ensures the report is structured, compliant and ready for regulatory consumption. 

### Workflow summary
This overview of the DRR structure explains how the workflow is organised:

 - **Projections** build on **Regulations**

- Which in turn draw on **Common** rules 

- Which call on **CDEs**

- Which leverage the DRR **Base** namespace. 

This hierarchical approach ensures that DRR is consistent, traceable and reusable across regulatory regimes.





