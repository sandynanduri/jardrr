---
title: Scope and structure
sidebar_label: Scope and structure
sidebar_position: 1
description: How DRR creates reports.
---


# Scope and structure

## Reporting regimes
DRR currently supports these trade and transaction reporting regimes:

### North America
- CFTC — Commodity Futures Trading Commission (United States)
- SEC — Securities and Exchange Commission (United States)
- CSA — Canadian Securities Administrators (Canada)

### Europe and United Kingdom
- ESMA — European Securities and Markets Authority (European Union)
- FCA — Financial Conduct Authority (United Kingdom)

### Asia‑Pacific
- ASIC — Australian Securities and Investments Commission (Australia)
- HKMA — Hong Kong Monetary Authority (Hong Kong)
- JFSA — Japan Financial Services Agency (Japan)
- MAS — Monetary Authority of Singapore (Singapore)






For each regulation, the model defines the set of regultory references together with their issuing authority. They are represented as:
- `Body` – the entity that is the author, publisher or owner of the referenced document
- `Corpus` – the document set that contains the referenced information

```
body Authority CFTC <"Commodity Futures Trading Commission (CFTC): The Federal regulatory agency established by the Commodity Futures Trading Act of 1974 to administer the Commodity Exchange Act.">

corpus Specifications "DTCC Specs" DTCC_Specs <"Document providing the message specifications required for inbound message for DTCC for CFTC.">

corpus Regulation "CFTC 17 CFR Parts 45 Version 3.0" Part45 <"Part 45 of the CFTCs regulations specifies the Commissions swap data recordkeeping and reporting requirements, pursuant to section 2(a)(13)(G) of the Commodity Exchange Act (CEA), which states that all swaps, whether cleared or uncleared, must be reported to a Swap Data Repository (SDR)">
```

The same structure is used for **standard-setting bodies**, such as CPMI–IOSCO’s Critical Data Elements (CDE):

```
body Authority CPMI_IOSCO <"IOSCO and the Committee on Payments and Market Infrastructures (CPMI) work together to enhance coordination of standard and policy development and implementation, regarding clearing, settlement and reporting arrangements including financial market infrastructures (FMIs) worldwide...">

corpus TechnicalGuidance "Harmonisation of Critical Data Elements (other than UTI and UPI)" CDE <"The G20 Leaders agreed in 2009 that all over-the-counter (OTC) derivative transactions should be reported to trade repositories (TRs) to further the goals of improving transparency, mitigating systemic risk and preventing market abuse...">
```





## Namespace
The DRR model adopts the **[CDM’s namespace structure](https://cdm.finos.org/docs/namespace/)**. DRR reporting logic sits in a dedicated **regulation layer**, using the below convention:
```
drr.regulation.<body>.<regulation>
```
Reporting regulations can themselves be subdivided, for instance when regulatory specifications are revised:
```
drr.regulation.cftc.rewrite
```
Reporting regulations are then further subdivided by report type:
```
drr.regulation.cftc.rewrite.trade
drr.regulation.cftc.rewrite.margin
drr.regulation.cfrc.rewrite.valuation
```

By design, the model is composable. Therefore, there are some components which are not specific to any regulation and are built to be resuable across several of them. These components can be found in the `drr.regulation.common` namespace.

Elements defined in other namespaces can also be reused throughout the model by **importing** that namespace. 
For example, CDE reporting rules defined in `drr.standards.iosco.cde` are leveraged and reused within the CFTC regulation namespace:

```
namespace drr.regulation.cftc.rewrite

import drr.standards.iosco.cde.*
```
This keeps the model modular, reusable, and consistent across jurisdictions. Read more about **[DRR namespace structure](./drr-namespace-structure.md)**.

## Reportable event 
All reporting regimes assume that reporting starts from a **transaction event**. In DRR, this is represented by the `ReportableEvent` data type. The `ReportableEvent` type **extends** `ReportableEventBase`. This means `ReportableEvent` (known as a _sub-type_) inherits all of its behaviour and attributes from `ReportableEventBase` (known as _super-type_) and adds its own behaviour and attributes on top.

```
type ReportableEvent extends ReportableEventBase: <"Specifies a workflowstep with enriched information required for reporting.">
    [rootType]
    override reportableInformation ReportableInformation (1..1) <"Additional information required for a reportable transaction, including the reporting regime.">

type ReportableEventBase:
    originatingWorkflowStep WorkflowStep (1..1) <"The workflowstep that originated the reportable event.">
    reportableTrade TradeState (0..1) <"The reportable trade decomposed from the originating workflow step when required.">
    reportablePosition CounterpartyPositionState (0..1) <"The reportable position decomposed from the originating workflow step when required.">
    reportableInformation ReportableInformationBase (0..1) <"Additional information required for a reportable transaction, including the reporting regime.">
```
In the CDM, the `WorkflowStep` data type, an attribute of `ReportableEvent`, is used to represent the state of a business event. While a `WorkflowStep` provides some reportable information, a transaction will typically need to be enriched with further information that is only relevant in a reporting context.

The dedicated `ReportableEvent` data type in the DRR model allows us to capture this additional, enriched information, ready for DRR consumption.



## Report definition
Each regulatory report is defined using three components:

- _What_ to report, i.e. the reportable fields
- _Whether_ to report – eligibility criteria.
- _When_ to report – timing (this is informational only, not executable).
  
```
report CFTC Part43 in T+1
    from TransactionReportInstruction
    when IsReportableEvent
  	with type CFTCPart43TransactionReport
```
The reportable fields are defined by specifying:
- A `body` and `corpus` as the source of the reporting mandate - `CFTC Part43`
- A timing constraint as a syntactic indication. Note this does not generate any executable code and therefore has no impact on the reporting process – `T+1`
- Eligibity criteria which references a functional rule that returns a Boolean – `IsReportableEvent`
- The report's output as a data type whose attributes represent the required reportable fields – `CFTCPart43TransactionReport`

In the report's output definition, each attribute (or reportable field) may be linked to a reporting rule through a `ruleReference`. A `ruleReference` contains the logic used to extract or compute the value to be reported for the associated attribute.

```
type CFTCPart43TransactionReport:
  [rootType]
  cleared string (1..1)
    [ruleReference Cleared]
  counterparty1 string (1..1)
    [ruleReference Counterparty1]
```
A report's output is validated using a `condition`. In the model, conditions are used to define the validation rules for reportable fields. Each `condition` evaluates to a Boolean value, and if it evaluates to False, the validation fails.

```
condition ReportingTimestampCondition:
[regulatoryReference CFTC Part43 appendix "1" dataElement "97" validationRule "Transaction"
    provision "M, the value shall be equal to or later than the value in [Execution timestamp]"]
        reportingTimestamp = executionTimestamp or reportingTimestamp > executionTimestamp
```

