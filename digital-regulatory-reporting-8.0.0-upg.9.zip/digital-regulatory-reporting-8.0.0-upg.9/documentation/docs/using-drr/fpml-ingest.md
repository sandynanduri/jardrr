---
title: FpML ingest
sidebar_label: FpML ingest
sidebar_position: 11
description: How DRR can ingest data directly from FpML.
---



# FpML ingest
DRR ingests data that has been transformed into the CDM. However, it can also directly ingest raw data from FpML, the shared language used by many banks, trading platforms and other financial institutions to describe complex trades.

FpML messages supported for ingestion to CDM and DRR:
- `FpML Confirmation To TradeState` – ingests a FpML messgae to produce a `TradeSate` (CDM object)
- `FpML Confirmation To WorkflowStep` – ingests a FpML message to produce a `WorkflowStep` (CDM object)
- `FpML RecordKeeping To ReportableEvent` – ingests a FpML message to produce a `ReportableEvent` (DRR object)

## `TradeState`
A `TradeState` is a pure representation of the trade itself. It only contains the details of the trade, without any information about how the trade came into existence or changed. Think of `TradeState` as a snapshot of the trade at a specific point in time.

It contains:
- Economic terms (e.g. notional, rate, dates, counterparties)
- No business event context
- No regulatory information

## `WorkflowStep` 
A `workflowStep` contains information about the business event for that trade, including:
- Trade information or `tradeState`
- Business event information (what is happening to the trade)

### Proposed event
At ingestion, the `WorkflowStep` details:
- The `ProposedEvent` (the proposed Buisness Event)
- The **before** `TradeState`
- The `PrimitiveInstruction` (the instruction to be applied to the **before** `TradeState`, a `QuantityChange` for example)

**Example: Ingest output (proposed event)** 
- Before: trade notional = 1,000,000
- Instruction: `quantityChange` decrease of 500,000
- After: not yet calculated
  
 **Proposed event = before `TradeState` + instruction**

### Business event
When data has been ingested to a `WorkflowStep`, functions in the CDM use the `PrimitiveInstuction` and the **before** `TradeState` to generate an **after** `TradeState`. Therefore what was once a proposed event, is transformed to a business event. The resulting, fully realised business event is reflected in DRR reports input within the `WorkflowStep`.

Post ingestion, the `WorkflowStep` therefore details:
- The `BusinessEvent`
- The **before** `TradeState`
- The `PrimitiveInstruction`
- The **after** `TradeState`

**Example: Report input (business event)**
- Before: trade notional = 1,000,000
- Instruction: `quantityChange` decrease of 500,000
- After: trade notional = 500,000

**Business event = before `TradeState` + instruction + after `TradeState`**

## `ReportableEvent`
Ingestion of an FpML `NonPublicExecutionReport` message generates a `ReportableEvent` - a DRR object. This represents the trade **as required for regulation**. It contains:
- Trade information or `TradeState`
- Buisness event information
- Regulatory reporting information
  



