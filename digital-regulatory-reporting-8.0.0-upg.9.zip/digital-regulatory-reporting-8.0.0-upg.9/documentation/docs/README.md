---
title: Overview
slug: /
---

# Digital Regulatory Reporting (DRR) documentation 

## About
The Digital Regulatory Reporting (DRR) open-access initiative from [ISDA](https://www.isda.org/) turns regulatory reporting from a painful chore into a clean, repeatable, relatively straightforward process. Built on the [FINOS Common Domain Model (CDM)](https://www.isda.org/isda-solutions-infohub/cdm/), it turns complex regulatory text into transparent, testable and reusable logic. 

It gives the industry a common foundation, reduces errors and frees people from the grind of decoding rules so they can focus on actual business, not bureaucracy.

This documentation provides essential information to guide you through the process – from understanding the model, to running the services, to contributing to the future of DRR.

[Official DRR documentation website](https://drr-docs.isda.org/next/)

![The DRR pipeline](../static/img/drr/drr-pipeline-2.png)

## Further information
- [DRR documentation (overview and guides)](https://drr-docs.isda.org/next/). The official DRR documentation.
- [FINOS CDM](https://www.finos.org/common-domain-model). Documentation on the Common Domain Model from FINOS.
- [FINOS CDM GitHub](https://github.com/finos/common-domain-model). The GitHub repository for CDM.
- [Rune DSL documentation](https://rune-docs.netlify.app/). Documentation for the Rune DSL, the domain-specific language designed for implementing DRR.
- [ISDA DRR](https://www.isda.org/isda-solutions-infohub/isda-digital-regulatory-reporting/). Additional info on DRR from ISDA.

## Governance
This product is distributed under a proprietary license. See [License Agreement](https://github.com/rosetta-models/digital-regulatory-reporting/blob/master/LICENSE.md) for details.
For non-commercial use, this product is available for free.

The DRR documentation is owned by **[ISDA](https://www.isda.org/)** and managed by **[Regnosys](https://regnosys.com/)**. 

Copyright © ISDA 2026.

## Contributing
To contribute to the documentation, send your suggestion to: CDMDRR@isda.org

## Contact us
You can write to us at: CDMDRR@isda.org



