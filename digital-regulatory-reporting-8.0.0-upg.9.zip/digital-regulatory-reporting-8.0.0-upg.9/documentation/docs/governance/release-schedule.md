title: Release schedule
sidebar_label: Release schedule

The Release Schedule outlines the states that we move between versions of CDM and DRR moving from Development, to Production, to Maintenance. More information on dates can be found [here](https://github.com/rosetta-models/digital-regulatory-reporting/blob/master/SCHEDULE.md)