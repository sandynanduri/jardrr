---
title: Development roadmap governance and process
sidebar_label: Development roadmap governance and process
sidebar_position: 3
description: How the DRR development roadmap evolves.
---


# DRR roadmap governance and process
DRR is constantly evolving, with regular updates and improvements contributing to its development roadmap. There are currently two Working Groups which oversee developments across DRR: the ISDA DRR Working Group and the DRR Steering Group. The Steering WG oversees the process and the integration across Working Groups.

**[2026 DRR Community Roadmap](https://github.com/rosetta-models/digital-regulatory-reporting/blob/master/ROADMAP26.md)**

## DRR Working Groups
- **ISDA DRR Working Group** (Chair: Tabish Ahmed. Fortnightly)
- **Steering Working Group** (Chair: David Shone. Monthly)

### ISDA DRR Working Group
The DRR WG is a call with representatives from various organisations across the industry with experience or interest in DRR that meets fortnightly to discuss issues that have been raised around DRR e.g. bugs, feature changes etc, as well as industry changes, deadlines and updates.

### Responsibilities

- Reviews, approves, and implements contribution proposals to DRR.
- Arbitrates disputes arising from DRR WG contributions.
- Guards and enforces design principles and guidelines.
- Triage and facilitates long-dated PRs and Issues.
- Meets fortnightly, with sub-groups as required.

## Meetings

**Join us on the Second and Fourth Tuesday at 9 AM EST (2 PM GMT).**

**Membership:** You can join this working group if you’re a member of a digital-regulatory-reporting repo or if you’re on the mailing list for the teams invite from ISDADataReporting@isda.org. 

You can also find details of upcoming calls on the [DRR Discussions board](https://github.com/rosetta-models/digital-regulatory-reporting/discussions).

To view meeting notes and agendas, view our [current](https://github.com/rosetta-models/digital-regulatory-reporting/issues?q=is%3Aissue%20state%3Aopen%20project%3Arosetta-models%2F18) and [past](https://github.com/rosetta-models/digital-regulatory-reporting/issues?q=is%3Aissue%20state%3Aclosed%20project%3Arosetta-models%2F18) GitHub Meeting Issues.

### DRR Steering Working Group

### Responsibilities

This group focuses on:
- Overall [governance](./governance-guidelines.md)
- [Release schedules for work completed](./major-release-scheduling-guidelines.md)
- [DRR production release schedule](https://github.com/rosetta-models/digital-regulatory-reporting/blob/master/SCHEDULE.md) 
- Agreements of roadmaps, strategy and direction.

**Membership:** Invite only. However, you can contact the group by email: cdmdrr@isda.org.

To view meeting notes and agendas, view our [current](https://github.com/rosetta-models/digital-regulatory-reporting/issues?q=is%3Aissue%20state%3Aopen%20project%3Arosetta-models%2F19) and [past](https://github.com/rosetta-models/digital-regulatory-reporting/issues?q=is%3Aissue%20state%3Aclosed%20project%3Arosetta-models%2F19) GitHub Meeting Issues. 
