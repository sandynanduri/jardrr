---
title: DRR Working Group Terms of Reference
sidebar_label: Working Group Terms of Reference
sidebar_position: 6
description: The systems that keep DRR at the forefront of regulatory reporting. 
---





# DRR Working Group Terms of Reference
#### 1 January 2026

## 1. Establishment and mandate
The Digital Regulatory Reporting (DRR) Working Group (the **“Working Group”**) is reconstituted as a single, consolidated DRR Working Group operating under the strategic oversight of the DRR Steering Group (the **“Steering Group”**). This restructure aligns DRR governance with the Common Domain Model (CDM) Working Group operating model and establishes GitHub as the primary mechanism for agenda and issue management.

### 1.1 Rationale for transition
ISDA is transitioning to this consolidated Working Group model to strengthen the DRR governance framework in preparation for expanded joint industry work, including increased coordination with industry partners such as ISLA and ICMA, and to support upcoming and evolving reporting jurisdictions that include a wider range of in-scope products, including OTC derivatives and other product classes. A single, globally consistent Working Group with transparent GitHub-based workflows will better enable multi-association collaboration, shared design discussions, and scalable contribution practices as DRR adoption and scope evolve.

The DRR Working Group is established to provide practical, multijurisdictional delivery support to the DRR initiative by translating Steering Group priorities into executable workstreams, technical outcomes, and implementable artefacts across the global derivatives market. The Working Group serves as an implementation-focused forum for adoption and non-adoption entities, reporting service providers, and other stakeholders to identify, discuss, evaluate, prioritise and progress DRR projects, enhancements, maintenance and adoption activities in a transparent and globally consistent manner.

The Working Group’s overarching objective is to promote safe, transparent, accurate and efficient regulatory reporting practices through delivery and continuous improvement of the DRR model. To achieve this, the Working Group will:
- Operate in the same format as CDM Working Groups, chaired by ISDA
- Manage the agenda and priorities through the DRR GitHub Projects page, with priorities set by the Chair in consultation with members and aligned to DRR Steering Group direction;
- Provide a forum for all contributors to raise and review pull requests and issues directly in GitHub, ensuring traceability, transparency, and consistency of the DRR contribution process
- Allocate dedicated agenda time for multi-lateral design discussions and community-wide questions from participating firms
- Draft, validate and propose enhancements to DRR logic, code and associated artefacts for DRR Steering Group review and escalation where needed
- Identify implementation issues, interpretive questions, and adoption blockers, and propose solutions for industry consideration
- Contribute to DRR education through playbooks, examples, implementation notes and knowledge-sharing sessions.

The **DRR Working Group**, as shown in the diagram, is intended to function as equivalent to other Domain Working Groups within the broader FINOS Working Group structure, enabling items impacting CDM design or contribution to be raised ultimately through the FINOS CDM Contribution Review Working Group (CRWG). Initial interaction with CDM WGs will likely occur at the Domain WG level e.g. product enhancements may go to the Derivatives WG or ISLA/ICMA WGs or collateral enhancements may go to the Collateral WG.

![DRR governance landscape](../../static/img/drr/drr-governance-landscape.png)

### 1.2 Key benefits of this approach
- Alignment of the DRR contribution process with CDM, enabling standardisation and greater process efficiency
- Familiarisation of DRR member firms with CDM working practices, ensuring global consistency and minimising the learning curve as they progress to CDM adoption
- Simplified governance through a single global DRR Working Group forum under the Steering Group
- Enhanced transparency and multi-regional coordination through GitHub-based backlog and agenda management.

## 2. Participation and consensus
### 2.1 Open participation
Participation in the Working Group is open to all interested stakeholders across adoption entities, service providers, infrastructure providers, relevant industry association, and other parties with a legitimate interest in DRR adoption, implementation and maintenance. ISDA will maintain a participant list and may invite subject-matter experts to relevant discussions as required.

### 2.2 Consensus and recommendations
The Working Group operates in a consultative and delivery capacity and does not hold final decision-making authority. The Working Group will seek to achieve majority-based consensus to form recommendations, technical outputs, and proposed deliverables for ISDA consideration and escalation to the Steering Group where needed.

Where majority consensus cannot be achieved, the Chair may: 
- Defer the matter for further analysis and re-discussion; and/or
- Escalate the matter to the DRR Steering Group or relevant DRR governing body for review or determination.

## 3. Meetings
### 3.1 Frequency
Meetings shall be held fortnightly on an alternate-week cadence to the FINOS CDM CRWG, enabling ongoing alignment and collaboration. Additional ad-hoc sessions may be convened as required by program milestones, UAT cycles or emerging issues.

### 3.2 Recording and minutes
Meetings may be recorded by ISDA and AI-generated transcripts may be used to assist minute-taking. Minutes shall:
- Summarise discussions, key points, and actions
- Be circulated within a reasonable timeframe
- Be archived in a designated repository by ISDA

### 3.3 Agenda, inputs and outputs
A standing agenda and materials, together with relevant inputs and outputs for each meeting, shall be prepared in advance of each meeting and published via the DRR GitHub Projects page. Working Group participants will be invited to propose agenda items or topics for upcoming meetings at least two days prior to each scheduled meeting, either through GitHub issues or directly to the Chair. Issues/topics raised after that may still make it into the meeting time, but this is not guaranteed.

Key outputs include, as applicable:
- GitHub issues capturing questions, defects and enhancement requests
- Pull requests for DRR logic, code, models, tests, and documentation
- Design notes and interpretive guidance arising from multilateral discussions
- Recommendations for DRR Steering Group consideration

## 4. Confidentiality
Participants shall maintain the confidentiality of non-public information disclosed during meetings, except where disclosure is required by law or expressly authorised by ISDA or the DRR Steering Group. Materials shared through the DRR Working Group shall not be used for commercial or competitive purposes.

## 5. Competition law compliance
All participants shall comply with applicable competition and antitrust laws. Participants agree not to exchange competitively sensitive information, discuss individual pricing or strategic commercial decisions, use the Working Group to reach any anticompetitive understanding, or otherwise coordinate market conduct. Each participant acts independently in all business decisions.

## 6. Record keeping and transparency
ISDA will maintain records of:
- Participation and attendance
- Agendas, minutes, and actions
- GitHub Projects backlogs, issues, pull requests and associated artefacts
- Written recommendations or outputs escalated to the DRR Steering Group

## 7. Amendments and review
These Terms of Reference may be reviewed and amended periodically by ISDA to ensure continued relevance, alignment with DRR Steering Group direction, CDM/FINOS governance and industry needs.

## 8. Effective date
These Terms of Reference are effective as of 1 January, 2026, and supersede any prior DRR Working Group terms.
