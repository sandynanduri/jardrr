---
title: DRR community roadmap
sidebar_label: DRR community roadmap
---

Each of the Working Groups owns its Roadmap, facilitated by the Chair. The Steering WG oversees the process and the integration across Working Groups.

Further details can be viewed [here](https://github.com/rosetta-models/digital-regulatory-reporting/blob/master/ROADMAP26.md)