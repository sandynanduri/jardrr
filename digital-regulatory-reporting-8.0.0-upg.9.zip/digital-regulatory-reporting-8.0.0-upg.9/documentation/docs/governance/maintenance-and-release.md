---
title: Maintenance and release
sidebar_label: Maintenance and release
---

## Reviewing model changes

Contributions are reviewed by the [DRR Working Group](./working-group-terms-of-reference.md)

### Review checklist

Before starting to review a contribution, the reviewer should go
through the following review checklist:

-   Review Pull Request to assert that:
    -   Model changes fulfil the proposed design and use-case
        requirements
    -   Mapping have been updated and output (JSON) looks correct
    -   Contributed model version is not stale and does not conflict
        with any recent changes
    -   Changes are in accordance with DRR governance guidelines, including the change control guidelines in the [change control guidelines page](./change-control-guidelines.md)

---
**Note:**
It is not yet possible to verify that mapping, validation and
qualification expectations have been maintained by looking at the output
of the Pull Request and DRR build only.

---
-   DRR build process completed with no errors or test failures
-   Review additional samples provided (if use-case is not covered by
    existing samples)
-   All model components positioned in the correct namespace
-   All model components have descriptions
-   Additional documentation provided, if necessary.
-   Release note provided

Any review feedback should be sent to the Contributor as required via
Slack, email or in direct meetings.

---

## Model maintenance and release

After learning about [how to edit](./editing.md) the model, please refer to this section to learn more about its maintenance. 

## Introduction

Before the Pull Request can be merged into DRR's main branch, some
work is usually required by the reviewer to preserve the integrity of
the model source code and of its downstream dependencies.

### Post-review technical tasks

A number of technical tasks may need to be performed on the Pull Request
once it is approved:

-   **Stale DRR version**: Contribution is based on an old DRR version
    and model changes conflict with more recent changes. If the
    conflicting change is available in Rosetta, the contributor should
    be asked to update their contribution to the latest version and
    resubmit. If the conflicting change is not yet available in Rosetta,
    this merge will need to be handled by DRR reviewer.
-   **Failed unit tests**: Java unit tests in DRR project may fail
    due to problems in the contributed changes. Alternatively it may be
    that the test expectations need to be updated. The reviewer should
    determine the cause of the test failure and notify either the
    Contributor or work on adjusting the test expectations.
-   **Code generation**: Model changes may cause code generator failures
    (e.g., Java, C#, Scala, Kotlin etc.). In the unlikely event of code
    generation failures, these will need to be addressed by the
    reviewer.

The change can be merged into the main DRR code base only upon:

-   approval by DRR reviewers and/or DRR Architecture and Review
    Committee,
-   successful completion of all the above technical tasks, and
-   successful builds of DRR and all its downstream dependencies.

## Releasing model changes

Once the contributed model change has been merged, a new release can be
built, tested and deployed. The reviewer will work with DRR Owners
and the Contributor on a deployment timeline.

The following release checklist should be verified before deploying a
new model:

-   Update DRR version number, using the [semantic
    versioning](./versioning.md) format
-   Build release candidate, and test
-   Build documentation website release candidate, and test
-   Deploy release candidate and notify channels if need be
-   (Currently done at a later stage) Update the latest DRR version
    available in Rosetta

---
**Note:**
When the release process is handled through Rosetta Deploy, the
reviewer should contact the Rosetta support team to request that
deployment and discuss a timeline for the release.

##  Release build approval guidelines

This section covers scheduling of minor, development, and patch releases, and approvals for all builds and releases.

## Development release scheduling and approvals
* Development releases may be scheduled by the reviewers to optimize development resources, based on the queue of approved PRs
  * There is no particular desired/expected release frequency; releases may be cut as soon as there is an approved PR, or several PRs may be consolidated into a single release at the convenience of the reviewers and dev staff
  * *Rationale:*  Development releases are expected to change in functionality, and getting changes out as quickly as practical is usually desirable.
  * Each development release shall require the approval of one reviewer once all the PRs are approved, and the test cases all pass successfully.
* Development releases shall be reported in brief to the DRR WG and the DRR SWG

## Major production release build and release approvals

* Major production releases will be scheduled by the DRR SWG as described above
* Each major production release shall require the approval of two reviewers after the following are complete:
  * The scope of the major production release is finalized and ratified by the DRR SWG
  * All approved PRs for the major production release are complete
  * The DRR SWG reviews the final list of enhancements in the release and signs off on releasing the development version into production

## Minor production release scheduling and approvals

* Minor production releases may be scheduled by the reviewers based on the queue of approved PRs
* Minor production releases to introduce enhancements should be combined  to minimize the number of production releases, targeting minor production releases to be issued around four weeks or so as long as there is a queue of approved PRs.  (This frequency can be increased in times of urgent need for new functionality).
  * *Rationale:*   Minimizing the number of production releases will help with supportability, by reducing the number of releases that end users wishing to remain current need to consider, and reducing communications overhead.
* Each minor production release shall require the approval of two reviewers.
* Minor production releases shall be reported in brief to the CRWG and the SWG, 
* A roadmap of anticipated minor production releases shall be reported by the reviewers to the DRR WG based on PRs that are in process.

## Production patch release scheduling and approvals

* Production patch releases to correct defects without releasing new functionality may be scheduled by the reviewers based on the presence of approved defect correction PRs, or other non-functional PRs (e.g. security remediations).
* Production patch releases require the approval of one reviewer
* Production patch releases shall be reported to the CRWG.

 ## Summary of release approval requirements

| Type of release      | Approval requirement |  Notes                                        |
| ---------------------| -------------------- |  -------------------------------------------  |
| Major Release (6.0.0)| 2 reviewers        | Scheduling via SWG; Include analysis of the changes from last major release as part of the approval  |
| Minor Release (6.1.0)| 2 reviewers        | Scheduling is up to the reviewers, but aim to keep to around every 4 weeks and no more than fortnightly       |
| Patch Release (6.1.1)| 1 reviewer         | Scheduling is up to the reviewer            |
| Development Release (6.0.0-dev.13)| 1 reviewer         | Scheduling is up to the reviewer            |
