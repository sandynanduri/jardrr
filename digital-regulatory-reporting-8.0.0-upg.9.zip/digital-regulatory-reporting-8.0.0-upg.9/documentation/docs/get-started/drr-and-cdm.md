---
title: DRR and the CDM
sidebar_label: DRR and the CDM
sidebar_position: 3
description: Learn how DRR uses the Common Domain Model (CDM).
---

 
## DRR and the CDM

The Common Domain Model (CDM) is the foundation of DRR. It provides a shared, unambiguous way to describe financial products, events and processes so that every firm, vendor and regulator can interpret data and rules in the same way. You can read the **[full documentation for the CDM](https://www.isda.org/isda-solutions-infohub/cdm/)** but here are a few highlights. 

### What is the CDM
The CDM is a standardised data model for representing:
- Financial products
- Trades and trade states
- Lifecycle events
- Processes and workflows
- Legal agreements


The CDM defines these concepts in a machine-readable and machine-executable format. Instead of each firm codifying the data for regulatory rules differently, the CDM ensures that everyone uses the same underlying structures and definitions.

### How DRR uses the CDM 
DRR uses the CDM as its **single source of truth** for:
- How trades are represented.
- How lifecycle events are applied.
- How derived fields are calculated.
- How reporting logic is executed.

This gives DRR three essential qualities:
- **Consistency:** The same input produces the same output across firms.
- **Transparency:** Every field and rule is explicitly defined.
- **Interoperability:** CDM based data can flow across systems without translation.

Without the CDM, DRR would be just another set of bespoke rules. With the CDM, DRR becomes a **shared industry standard**.

### Core components of the CDM
The CDM is organised into several key building blocks:


#### 1. Product
Defines the economic terms of a trade, including payouts, notionals, prices and product identifiers.

#### 2. Trade and TradeState
Represents the trade itself and its current state at any point in time.

#### 3. Event
Describes lifecycle events such as new trades, amendments, terminations, compressions and allocations. Events are applied to TradeStates to produce updated states.

#### 4. Party and roles
Identifies the parties involved in a transaction and their roles (e.g. counterparty, reporting party).

#### 5. Processes
Standardised workflows that describe how events are applied and how states evolve.

