---
title: How DRR works
sidebar_label: How DRR works
sidebar_position: 3
description: Learn how DRR goes from regulatory text to reporting output.
---



# How DRR works
Digital Regulatory Reporting ([DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr)) works by turning complex regulatory requirements into structured, machine‑readable logic that can be reused, tested, and executed consistently across jurisdictions. Instead of firms implementing their own interpretation of regulatory requirements, DRR presents an industry-led interpretation and understanding in a shared model that defines what needs to be reported and how the rules should be applied.

## DRR workflow
The [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) workflow aims to translate regulatory text into machine-executable logic to produce standardised reporting outputs across jurisdictions.

### 1: Industry-led interpretation
The DRR project brings together different firms, large and small, to convert the often ambiguous and inconsistent language of regulatory text into logical code that is traceable and human-readable. 

Working groups meet to discuss the reporting requirements for each regime, determining the required output for each field. Any ambiguous or unclear requirements are determined by group consensus, and if there is still an impasse then the group can go to the regulators directly. 

Regulatory text may include:

- [CFTC](https://drr-docs.isda.org/next/docs/resources/glossary#cftc) Part 43/45
- [EMIR](https://drr-docs.isda.org/next/docs/resources/glossary#emir) RTS/ITS
- [ASIC](https://drr-docs.isda.org/next/docs/resources/glossary#asic) DTR
- [MAS](https://drr-docs.isda.org/next/docs/resources/glossary#mas) reporting rules
- [JFSA](https://drr-docs.isda.org/next/docs/resources/glossary#jfsa) OTC reporting
- [MiFID](https://drr-docs.isda.org/next/docs/resources/glossary#mifid)/[MiFIR](https://drr-docs.isda.org/next/docs/resources/glossary#mifir)

### 2: Collaborative implementation effort
Following working group consensus on how fields should be reported, the interpretation is translated into DRR rules to build reports for the necessary jurisdictions. Because DRR is open access, the implementation effort can be spread across different industry participants meaning the workload and barrier to entry is significantly reduced for those seeking to adopt it. 

Rune DSL (the domain-specific language designed for DRR) and DRR itself, are designed to be readable by professionals with domain knowledge (e.g. regulatory analysts), regardless of their programming competence or experience. This means that reporting logic can be written by any team member who understands the requirements and the regulation. 

Working groups continue to meet regularly to discuss new or proposed changes to the model. 

### 3: Scalable report design
DRR is designed to reduce duplication where possible while reusing components and logic across jurisdictions. Critical Data Elements set by the Committee on Payments and Market Infrastructures (CPMI) and the International Organization of Securities Commissions (IOSCO), and common reporting fields act as the foundation for every regime, each leveraging the core components on a transcation report and further extending it to support their own reporting requirements. Logic only needs to be written once and it can be reused multiple times, making implementation of new jurisdictions faster. 

```
type CommonTransactionReport extends cde.CriticalDataElement: <"Common Transaction Report represents common attributes">
```

### 4: Built-in testing and validation
Each report output in DRR is evaluated against a set of mandated data validation rules. These conditions and validations verify the data is correct syntactically, logically, and in accordance with allowable values set by the regulators. 

This example shows a commonised validation rule that checks that `counterparty1` must not be the same as `counterparty2`.
```
    condition DTCC_ASIC_BR_1006_01: <"Counterparty 1">
        [docReference ASIC DTCC_Specs table "1" dataElement "6" validationRule "Transaction"
        provision "when [Action Type] = NEWT, MODI, CORR, REVI, TERM, PRTO, ERROR, MARU, VALU then [Counterparty 1] must NOT = [Counterparty 2] if [Counterparty 2 identifier type] is = LEI"]
        common.party.Counterparty_Validation(
                actionType,
                counterparty2IdentifierType,
                counterparty1,
                counterparty2
            )
```

Synthetic data samples for each step’s inputs and output are captured in a 'Test Pack' that allows users to validate any implementation against those tests. Users can also test against their own proprietary data with their own anonymised samples.








