---
title: Introducing DRR
sidebar_label: Introducing DRR
sidebar_position: 2
description: Your introduction and first steps to using DRR.
---




# Introducing DRR

**Digital Regulatory Reporting ([DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr))** is an open-access, cross-industry initiative to transform regulatory reporting requirements into an industry-agreed implementation of unambiguous, machine-executable code. Instead of relying on lengthy rulebooks and firm-specific interpretations, industry participants collaborate to interpret and build the open-access DRR model, making transaction reporting more efficient and cost effective than ever.  DRR extends the Common Domain Model ([CDM](https://drr-docs.isda.org/next/docs/resources/glossary#cdm)) for the purpose of regulatory reporting, leveraging the open-source data standard for financial products, trades, and lifecycle events.

DRR is designed to provide **standardised and collaborative implementation of reporting logic** that moves away from siloed interpretation and implementation toward an **industry-led machine-executable, human-readable design**. This creates a single, authoritative representation of what each rule means and how it should be applied, so there's no ambiguity in the reporting process.

### Consistent and transparent
Through industry collaboration, [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) reduces interpretation risk, eliminates duplicated implementation effort and provides a shared code base that can be reused across jurisdictions. Reporting rules are interpreted by the industry and implemented in a common, reusable way, limiting the need for siloed implementation projects at individual firms and across different jurisdictions. [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) also accelerates onboarding for new regulations since teams can build on common and reusable components.

For regulators and the wider market, [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) delivers a standardised implementation of reporting logic. When every participant applies the same logic, supervisory analysis becomes more reliable and systemic risks become easier to detect. The transparency of the model – every rule visible, versioned and reviewable – supports stronger governance and clearer communication between industry and regulators.

In short, [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) replaces fragmented interpretations with a **shared, executable source of truth** that raises the quality and efficiency of regulatory reporting across the entire ecosystem.


## Benefits of using DRR
- **Consistency:** By following established design principles and a unified modelling guide, all users ensure their **reporting** data meets the same regulatory standards and that they're 100% aligned with best practice.
- **Transparency:** The scope and status of reporting requirements are clearly defined, reducing ambiguity for implementers. All data is traceable and all rules and reportable fields annotated with the relevant provisions, regulatory references, and peer review decisions, so that firms, auditors and regulators can understand exactly **why** a value appears in a report.
- **Efficiency:** The workflow automates the path from raw data to final regulatory projection, minimising manual errors. Because core logic is shared across jurisdictions where possible, [DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) avoids duplication and applies jurisdiction-specific logic only where it’s required. New regulations can leverage existing logic, meaning implementation is faster and at the same standard as any existing regulations.
- **Compliance:** Each regulation is reviewed and interpreted by industry-led working groups. This interpretation is then written into DRR, with each field  annotated with regulatory references, working group decisions and ISDA best practices. Compliance has never been easier, with each rule being now being traceable to the field in the regulation and any ambiguity traceable to the working group decision or the ISDA best-practice publication. DRR is written in Rune, a human-readable coding language, meaning stakeholders from across the spectrum  (compliance, executive leadership, regulators) can understand exactly how a reporting output is derived. 
- **Interoperability:** The [CDM](https://drr-docs.isda.org/next/docs/resources/glossary#cdm) ensures data is structured the same way across firms so everyone is using the same representation of the financial data.
- **Reduced cost:** Integrating open-access solutions can save significantly on IT expenditure. DRR 7 currently supports nine jurisdictions, and the burden of updating or adding jurisdictions is significantly reduced, with the cost and implementation effort spread across the firms involved.





## How it works
[DRR](https://drr-docs.isda.org/next/docs/resources/glossary#drr) brings together stakeholders across the industry to intepret and then implement regulatory text.

Learn more in [How DRR works](https://drr-docs.isda.org/next/docs/get-started/how-drr-works).


## Scope and jurisdictions
DRR covers a range of trade and transaction reporting regimes, including:

### North America
- CFTC — Commodity Futures Trading Commission (United States)
- SEC — Securities and Exchange Commission (United States)
- CSA — Canadian Securities Administrators (Canada)

### Europe and United Kingdom
- ESMA — European Securities and Markets Authority (European Union)
- FCA — Financial Conduct Authority (United Kingdom)

### Asia‑Pacific
- ASIC — Australian Securities and Investments Commission (Australia)
- HKMA — Hong Kong Monetary Authority (Hong Kong)
- JFSA — Japan Financial Services Agency (Japan)
- MAS — Monetary Authority of Singapore (Singapore)






