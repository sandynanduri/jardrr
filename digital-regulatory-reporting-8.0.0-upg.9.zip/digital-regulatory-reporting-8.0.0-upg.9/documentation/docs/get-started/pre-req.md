---
title: Prerequisites
sidebar_label: Prerequisites
sidebar_position: 1
description: What you'll need before you start using DRR.
---


# Prerequisites and dependencies
What you'll need to get started with DRR:

- **CDM Data:** Transaction and event data converted to the Common Domain Model (CDM).
- **Rune DSL:** An understanding of the domain-specific language used for modelling CDM and DRR logic.
- **Access to DRR from ISDA:** Please contact [CDMDRR@isda.org](mailto:CDMDRR@isda.org)
- **Development environment:** e.g. Eclipse, the Rosetta platform or other environment capable of processing DRR.
- **DRR:** A working knowledge of principles and implementation of Digital Regulatory Reporting.
- **CDM:** An understanding of the principles behind the [CDM open-source data standard](https://www.isda.org/isda-solutions-infohub/cdm/).
