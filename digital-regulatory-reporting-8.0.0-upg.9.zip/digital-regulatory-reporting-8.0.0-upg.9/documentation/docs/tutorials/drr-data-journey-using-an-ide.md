---
title: DRR data journey using an IDE
sidebar_label: DRR data journey using an IDE
sidebar_position: 8
description: How to use DRR in an Integrated Development Environment
---
 
 

# DRR data journey using an IDE

The development environment may be different for each firm – DRR is not tied to a specific development environment. Below is a simplified, generic example of how to use DRR to produce a report using an IDE (Integrated Development Environment) such as Visual Studio Code, IntelliJ IDEA, Eclipse or PyCharm. 

Whichever environment you use, the process is essentially the same, as DRR processes a trade event (which has been converted into the CDM), enriches it with regime-specific logic, and ultimately produces the correct regulatory report for a given jurisdiction (e.g. DTCC RDS Harmonized).

## 1. Start with the CDM event
Everything begins with a CDM trade event. This is the raw representation of what happened: a new trade, an amendment, a termination, etc.
```
type ReportableEvent { event: CdmEvent } 
```

This stage captures the trade lifecycle event in a standard CDM format so DRR has a clean, consistent starting point.

## 2. Attach the regulatory context
Next, DRR takes the CDM event and wraps it in a structure that prepares it for a specific regime: 

```
func Create_RegimeReportableEvent(event: ReportableEvent, regime: Regime) 
```

This stage prepares the event for a particular regulator (e.g. CFTC, ESMA, MAS) by applying the correct reporting rules.


## 3. Apply regime-specific logic
This is where DRR interprets the CDM event through the lens of the chosen regime.

```
type RegimeReportableEvent extends ReportableEvent { regimeContext: Regime } 
```

This stage applies the required regime specific rules, handles overrides and normalises the data according to that regulator’s expectations. 


## 4. Convert the event into a report instruction
Next, DRR transforms the regime interpreted event into a transaction report instruction.

```
func Create_TransactionReportInstructionForRegime(rre: RegimeReportableEvent) 
```

This stage turns the regulatory interpretation into a specific instruction that outlines the type of report to be produced and the data required to build it. 


## 5. Per regime reporting logic
Each regulator has its own reporting structure – this data type captures the structure required.

```
type TransactionReportInstructionForRegime { reportFields: RegimeSpecificFields } 
```

This stage defines the exact fields, formats, timestamps, and logic required by the supervisory body (e.g. DTCC, ASIC, MAS). This is the point where the output diverges depending on the jurisdiction.


## 6. Final projection to the jurisdiction's report format
From the instruction, DRR produces the final regulatory report. For example, under the Canadian Securities Administrators (CSA) workflow, the instruction may be projected into one of two outputs:

#### Option A – CSA Trade Report
`CSA_Trade Project_CSATradeReportToDtccRdsHarmonized`

#### Option B – CSA PPD Report
`CSA_PPD Project_CSAPpdReportToDtccRdsHarmonized`

This stage converts DRR’s internal representation into the regulator’s required schema. It then applies final formatting and harmonization rules to produce the exact structure expected by DTCC RDS Harmonized (or another TR).

