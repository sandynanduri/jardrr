---
title: DRR data journey using Rosetta
sidebar_label: DRR data journey using Rosetta
sidebar_position: 9
description: Use the Rosetta platform to deliver DRR.
---

 

# DRR data journey using Rosetta


This page explains the full end-to-end workflow using the **Rosetta** platform for converting an **FpML Recordkeeping XML** into a:

1. **DRR ReportableEvent**

2. **TransactionReportInstruction**

3. **Regulatory transaction report**, and finally

4. **ISO 20022 XML projection**



## 1. Ingest
1.1. [Create a **DRR workspace** in Rosetta](https://docs.rosetta-technology.io/rosetta/rosetta-products/1-workspace/).

1.2. Open the **Ingest** panel.

1.3. Upload your own FpML sample or select a preloaded test file (e.g. Equity Option Price Return Basket ex01 New).

Rosetta uses these functions to ingest different FpML message types to produce CDM or DRR object outputs:
- `FPML Confirmation To TradeState` – Ingests the message to create a CDM `TradeState` output. This represents only the trade itself, providing a snapshot at a specific point in time without any business event details or regulatory information.
- `FPML Confirmation To WorkflowStep` – Ingests the message to create a CDM `WorkflowStep` output. This adds context about the business event being applied (such as contract formation). The output includes both `TradeState` data and the associated `BusinessEvent details`.
- `FPML Confirmation To ReportableEvent` – Ingests the message to create a DRR `ReportableEvent` output. The output contains `TradeState` and `WorkflowStep` information, along with regulatory data related to the trade, such as the financial nature of the counterparty.

Of these three ingest functions, only `FPML Confirmation To ReportableEvent` produces a DRR object (`ReportableEvent`) as its output. This is because the input message includes regulatory information that allows it to be ingested directly into a `ReportableEvent`. 


![Click on Ingest at the bottom of the screen](../../static/img/drr/rosetta-1-click-on-ingest-at-the-bottom-of-the-screen.png)

1.4. When the `FPML 5 Confirmation To ReportableEvent` function is called, it directly produces a **DRR ReportableEvent** as an output. The diagnostics on the right of the screen reveal any issues in the testing.

![Click on the file to run Ingest](../../static/img/drr/rosetta-2-click-on-the-file-to-run-ingest.png)


## 2. Enrich
2.1. Open the **Enrich** panel.

2.2. Select the **Enrich** function from the dropdown.

2.3. Upload `ReportableEvent` from the previous step or select a preloaded test file from the table of samples. (e.g. Equity).

2.4. The Enrich service runs and produces a DRR `TransactionReportInstruction` enriched with additional required data from internal or external sources.


![Upload your own DRR object](../../static/img/drr/rosetta-10-upload-your-own-drr-object.png)

![Click the file to run the enrich service](../../static/img/drr/rosetta-11-click-the-file-to-run-the-enrich-service.png)


## 3. Reports
3.1. Open the **Reports** panel.

3.2. Select a report type (e.g. **ESMA / EMIR Trade**) and a test pack (e.g. Equity).

3.3. Upload the `TransactionReportInstruction` from the previous step (e.g. Equity_Option_Example) or select a preloaded test file from the table of samples.


![Click on Reports at the bottom of the screen](../../static/img/drr/rosetta-5-click-on-reports-at-the-bottom-of-the-screen.png)

![You will see the uploaded file shown on the screen](../../static/img/drr/rosetta-6-you-will-see-the-uploaded-file-shown-on-the-screen-as-below.png)


3.4. The Report service runs and produces a single regime-specific `TransactionReport` with that regime's logic applied.

![Click on the file to view the report](../../static/img/drr/rosetta-7-click-on-the-file-to-view-the-report.png)


## 4. Projection
4.1. Open the **Projection** panel.

4.2. Select a projection (e.g. **EsmaEmirTradeReportToIso20022**) and a test pack (e.g. Equity).

4.3. Upload the `TransactionReport` JSON from the previous step (e.g. Equity_Option_Example_Upload) or select a preloaded test file from the table of samples.

![Click on the projection at the bottom of the screen](../../static/img/drr/rosetta-8-click-on-the-projection-at-the-bottom-of-the-screen.png)

![You will see the uploaded file and your file from the previous step](../../static/img/drr/rosetta-9-you-will-see-the-uploaded-file-and-your-file-from-the-previous-step.png)

4.4. The Projection service runs and produces the correctly formatted projection for the chosen regime (e.g. ISO 20022 XML, DTCC Harmonized XML). 

![Click the file to run the projection service](../../static/img/drr/rosetta-10-click-the-file-to-run-the-projection-service.png)


