import { themes as prismThemes } from 'prism-react-renderer';
import type { Config } from '@docusaurus/types';
import type * as Preset from '@docusaurus/preset-classic';
import type { GlossaryPresetOptions } from 'docusaurus-plugin-glossary/preset';

// This runs in Node.js - Don't use client-side code here (browser APIs, JSX...)

const hostname = process.env.DOCS_HOSTNAME ?? 'drr-docs.isda.org';
const siteUrl = `https://${hostname}/`;

const baseUrl = '/next/';

const config: Config = {
  title: 'DRR Documentation',
  tagline: 'Digital Regulatory Reporting (DRR) is an open‑access initiative that turns global derivatives reporting rules into clear, machine‑readable logic.\n' +
      'This site is your guide to understanding how DRR works, how to use it, and how to contribute to the wider ecosystem.',
  favicon: 'img/drr/isda_logo.svg',

  // Future flags, see https://docusaurus.io/docs/api/docusaurus-config#future
  future: {
    v4: {
      fasterByDefault: false,
    },
  },
  url: siteUrl,
  // Set the /<baseUrl>/ pathname under which your site is served
  // For GitHub pages deployment, it is often '/<projectName>/'
  baseUrl,

  // GitHub pages deployment config.
  // If you aren't using GitHub pages, you don't need these.
  organizationName: 'ISDA', // Usually your GitHub org/user name.
  projectName: 'digital-regulatory-reporting', // Usually your repo name.

  onBrokenLinks: 'warn',
  trailingSlash: true,

  markdown: {
    hooks: {
      onBrokenMarkdownImages: 'ignore',
    },
  },

  // Even if you don't use internationalization, you can use this field to set
  // useful metadata like html lang. For example, if your site is Chinese, you
  // may want to replace "en" with "zh-Hans".
  i18n: {
    defaultLocale: 'en',
    locales: ['en'],
  },

  presets: [
    [
      'docusaurus-plugin-glossary/preset',
      {
        // Glossary configuration
        id: 'glossary',
        glossary: {
          glossaryPath: 'docs/resources/glossary.json',
          routePath: `${baseUrl}docs/resources/glossary`,
        },
        // Standard Docusaurus preset-classic options
        docs: {
          sidebarPath: './sidebars.ts',
          showLastUpdateAuthor: true,
          showLastUpdateTime: true,
          editUrl: undefined,
          lastVersion: 'current',
          versions: {
            current: {
              label: 'next',
              path: '',
            },
          },
        },
        blog: false,
        theme: {
          customCss: './src/css/custom.css',
        },
      } satisfies GlossaryPresetOptions,
    ],
  ],

  plugins: [
    [
      require.resolve("@easyops-cn/docusaurus-search-local"),
      {
        hashed: true,
        indexDocs: true,
        docsRouteBasePath: "/docs",
      },
    ],
  ],

  themeConfig: {
    image: 'img/drr/drr-social-card.png',
    /* algolia: {
      appId: 'YOUR_APP_ID',
      apiKey: 'YOUR_SEARCH_API_KEY',
      indexName: 'YOUR_INDEX_NAME',
      contextualSearch: true,
    }, */
    colorMode: {
      defaultMode: 'light',
      disableSwitch: true,
      respectPrefersColorScheme: false,
    },
    navbar: {
      title: '',
      logo: {
        alt: 'ISDA Digital Regulatory Reporting', 
        src: 'img/drr/isda_logo.svg',
        srcDark: 'img/drr/isda_logo.svg',
      },
      style: 'dark',
      items: [
        {
          type: 'docsVersionDropdown',
          position: 'right',
          dropdownItemsAfter: [
            {
              label: '6.0.0',
              href: `${siteUrl}6.0.0/`,
            },
            {
              label: '7.0.0',
              href: siteUrl,
            },
          ],
        },
        {
          href: 'pathname:///DRR_Documentation.pdf',
          label: 'Download PDF',
          position: 'right',
        },
      ],
    },
    footer: {
      style: 'dark',
      logo: {
        alt: 'ISDA Logo',
        src: 'img/drr/isda_logo.svg',
        width: 120,
      },
      links: [
        {
          title: 'About ISDA',
          items: [
            {
              label: 'Privacy Policy',
              href: 'https://www.isda.org/privacy-policy/',
            },
            {
              label: 'Terms & Conditions',
              href: 'https://www.isda.org/terms-conditions/',
            },
          ],
        },
        {
          title: 'Connect',
          items: [
            {
              label: 'LinkedIn',
              href: 'https://www.linkedin.com/company/isda/',
            },
          ],
        },
      ],
      copyright: `©2026 International Swaps and Derivatives Association, Inc. ISDA is a registered trademark of the International Swaps and Derivatives Association, Inc.`,
    },
    prism: {
      theme: prismThemes.github,
      darkTheme: prismThemes.dracula,
      additionalLanguages: ['haskell'],
      magicComments: [
        {
          className: 'theme-code-block-highlighted-line',
          line: 'highlight-next-line',
          block: {start: 'highlight-start', end: 'highlight-end'},
        },
      ],
    },
  } satisfies Preset.ThemeConfig,
};

export default config;
