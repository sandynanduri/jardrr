.. _DRR Distribution: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/distribution/$LATEST_RELEASE_ID/distribution-$LATEST_RELEASE_ID.zip
.. _DRR Examples: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/examples/$LATEST_RELEASE_ID/examples-$LATEST_RELEASE_ID.zip
.. _DRR Distribution PROD 5: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/distribution/5.59.0/distribution-5.59.0.zip
.. _DRR Examples PROD 5: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/examples/5.59.0/examples-5.59.0.zip
.. _DRR Distribution PROD 6: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/distribution/6.26.1/distribution-6.27.0.zip
.. _DRR Examples PROD 6: https://europe-west1-maven.pkg.dev/production-208613/isda-maven/com/regnosys/drr/examples/6.26.1/examples-6.27.0.zip
