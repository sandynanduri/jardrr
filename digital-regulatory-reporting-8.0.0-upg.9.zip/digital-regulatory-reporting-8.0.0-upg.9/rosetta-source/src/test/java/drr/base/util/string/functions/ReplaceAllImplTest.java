package drr.base.util.string.functions;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ReplaceAllImplTest {

    ReplaceAll func;

    @BeforeEach
    void setUp() {
        func = new ReplaceAllImpl();
    }

    @Test
    void shouldReplaceMatchedString() {
        String result = func.evaluate("apple pie", "p", "b");
        assertEquals("abble bie", result);
    }

    @Test
    void shouldReplaceComplexRegex() {
        String result = func.evaluate("ID: 12345", "\\d+", "[REDACTED]");
        assertEquals("ID: [REDACTED]", result);
    }

    @Test
    void shouldReturnOriginalStringWhenNoMatchFound() {
        String result = func.evaluate("hello world", "xyz", "abc");
        assertEquals("hello world", result);
    }

    @Test
    void shouldReturnNullWhenInputIsNull() {
        String result = func.evaluate(null, "regex", "replacement");
        assertNull(result);
    }

    @Test
    void shouldReturnOriginalStringWhenRegexIsNull() {
        String result = func.evaluate("hello", null, "replacement");
        assertEquals("hello", result);
    }

    @Test
    void shouldReturnOriginalStringWhenReplacementIsNull() {
        String result = func.evaluate("hello", "regex", null);
        assertEquals("hello", result);
    }

    @Test
    void shouldHandleEmptyInputString() {
        String result = func.evaluate("", "regex", "replacement");
        assertEquals("", result);
    }

    @Test
    void shouldHandleNullInputs() {
        assertNull(func.evaluate(null, "regex", "replacement"));
        assertEquals("hello", func.evaluate("hello", null, "replacement"));
        assertEquals("hello", func.evaluate("hello", "regex", null));
    }
}
