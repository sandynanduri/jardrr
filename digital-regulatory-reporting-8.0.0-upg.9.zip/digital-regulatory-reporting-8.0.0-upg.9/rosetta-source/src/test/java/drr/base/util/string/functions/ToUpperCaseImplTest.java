package drr.base.util.string.functions;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ToUpperCaseImplTest {

    ToUpperCase func;

    @BeforeEach
    void setUp() {
        func = new ToUpperCaseImpl();
    }

    @Test
    void shouldConvertLowerCaseToUpperCase() {
        String result = func.evaluate("hello world");
        assertEquals("HELLO WORLD", result);
    }

    @Test
    void shouldKeepUpperCaseAsIs() {
        String result = func.evaluate("HELLO WORLD");
        assertEquals("HELLO WORLD", result);
    }

    @Test
    void shouldHandleMixedCaseAndSpecialCharacters() {
        String result = func.evaluate("aB3cD!@#");
        assertEquals("AB3CD!@#", result);
    }

    @Test
    void shouldHandleEmptyString() {
        String result = func.evaluate("");
        assertEquals("", result);
    }

    @Test
    void shouldReturnNullWhenInputIsNull() {
        assertNull(func.evaluate(null));
    }
}
