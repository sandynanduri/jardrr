package drr.regulation.common.functions;

import cdm.base.math.metafields.FieldWithMetaNonNegativeQuantitySchedule;
import cdm.observable.asset.PriceQuantity;
import com.rosetta.model.lib.meta.Key;
import com.rosetta.model.metafields.MetaFields;
import drr.base.trade.functions.GetQuantityKeys;

import java.util.*;
import java.util.stream.Collectors;

public class GetQuantityKeysImpl extends GetQuantityKeys {

    @Override
    protected List<String> doEvaluate(PriceQuantity priceQuantity) {
        // CDM/DSL version upgrade: PriceQuantity.getQuantity() is now single cardinality
        // (FieldWithMetaNonNegativeQuantitySchedule) instead of a list.
        return Optional.ofNullable(priceQuantity)
                .map(PriceQuantity::getQuantity)
                .map(FieldWithMetaNonNegativeQuantitySchedule::getMeta)
                .map(MetaFields::getKey)
                .orElse(Collections.emptyList())
                .stream()
                .map(Key::getKeyValue)
                .filter(Objects::nonNull)
                .distinct()
                .collect(Collectors.toList());
    }
}
