package drr.base.util.string.functions;

import java.util.Optional;

/**
 * Converts the input string to uppercase, safely returning null if the provided input is null
 */
public class ToUpperCaseImpl extends ToUpperCase {

    @Override
    protected String doEvaluate(String input) {
        return Optional.ofNullable(input)
                .map(String::toUpperCase)
                .orElse(null);
    }
}
