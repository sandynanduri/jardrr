package drr.base.util.string.functions;

/**
 * Replaces all regex matches in a string with a replacement, returning null if the input is null, or the unmodified input if either the regex or replacement is null
 */
public class ReplaceAllImpl extends ReplaceAll {
    @Override
    protected String doEvaluate(String input, String regex, String replacement) {
        if (input == null) {
            return null;
        }

        if (regex == null || replacement == null) {
            return input;
        }

        return input.replaceAll(regex, replacement);
    }
}
