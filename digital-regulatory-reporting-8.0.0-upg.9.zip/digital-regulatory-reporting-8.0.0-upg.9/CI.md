--- 
# Continuous integration
---

## What is a 'build' and 'continuous integration'?

A build process starts with source artefacts (i.e. this repository) and (i) produces all the artefacts that are used by external actors, and may (ii) deploy the artefacts where those actors expect to find them.

The build process performs many tests and verifications along the way.

Running a build process frequently catches problems early and ensures quality is maintained. This is known as '**continuous integration**' (CI).

When the generated artefacts are deployed, this is '**continuous deployment**' (CD).


## The DRR build process

For DRR, the source artefacts include files containing [Rune](https://github.com/rosetta-models/digital-regulatory-reporting/tree/master/rosetta-source), the artefacts that are used externally include Java libraries generated from Rune and the documentation website HTML.

A build process is invoked automatically for every source change. 

A release is created by manually invoking a build process including the deploy steps (see [here](./README.md)). 

The deploy steps include publishing the Java libaries to ISDA's Maven repository and refreshing the [DRR documentation website](https://drr-docs.isda.org/).


## How can I see details of each build?

Releases of DRR are built by a third-party continuous integration tool called [CodeFresh](https://codefresh.io/docs/docs/getting-started/intro-to-codefresh/).

There are links from [DRR on GitHub](https://github.com/rosetta-models/digital-regulatory-reporting) to CodeFresh. The build triggered by the last commit to each branch/tag is available as a GitHub commit status. They are indicated by a small tick or cross in the title row of repository content view. Clicking on them shows links through to CodeFresh. 


## What does building a release do?

In CodeFresh, you can see columns representing build 'stages', each with a sequence of steps shown vertically:

1. SETUP – prepares various settings and build variables that are used later
2. BUILD – does the real work:
    1. Tests the DRR model using samples against expectations: see What are expectations? 
    2. Generate Java from the Rune
    3. Compiles the Java to Java libraries
    4. Deploys the Java libraries to Maven central
    5. Builds the DRR documentation website
3. RC – deploys to the DRR documentation RC website
4. PROD – deploys to the DRR documentation Production website
5. FINALISE – sends a notification email with the details


## How do I know a release was built successfully and completely?

CodeFresh self-reports success against each step:

- Green tick means success
- Grey arrow means skipped
- Red cross means failed

In addition, a release build completion notification email is only sent if everything succeeded. It contains links to the items created by the build process, for example the email body (for **v8.1.0**):

>The digital-regulatory-reporting release 8.1.0 complete. Maven artifacts are available now. The model will be visible in Rosetta within an hour.
>
>Release tag: https://github.com/rosetta-models/digital-regulatory-reporting/tree/8.1.0
>
>Release notes: https://github.com/rosetta-models/digital-regulatory-reporting/releases/tag/8.1.0
>
>DRR documentation: https://drr-docs.isda.org/next/
> 

# What are expectations?

The high quality of DRR is ensured by an extensive set of test samples and their expected output.

Test samples are trades represented in FpML, and the expected outputs are TR reports (often ISO 20022) that are produced for each.

Both the test samples and the expected outputs are stored in the Github repository, alongside the Rune model.

DRR can be tested by: for each test sample, comparing the **actual** TR report that is produced against the test sample's **expected** TR report.

The build process checks every test sample. If a single test sample produces an actual TR report different from expected, the build process will fail.

DRR contributors are required to perform this testing themselves before they submit a contribution to ensure the build process will pass when their changes are merged.

If, as a result of their model alteration, a test sample's output changes, a contributor must consider if the output change is intended or not. It could be intended because the actual output is different from expectations in exactly the way the contributor wants. Or it could be unintended because the actual output is different from expectations in an undesirable way. Only if the difference is intended should they 'accept changed expectations’: updating the expected output with the actual output.

DRR contributors must include all changed expectations alongside their Rune model change or else the build process will fail.

# Software security: CVEs

The open source project [Dependency-Check](https://owasp.org/www-project-dependency-check/) from [OWASP](https://owasp.org/) is used to protect against CVEs.

Dependency-Check obtains the set of libraries that DRR depends on, and looks-up each against the [National Vulnerability Database (NVD)](https://nvd.nist.gov/). 

A failure is triggered if any library has a CVE with severity greater than 7.0.

Dependency-Check is invoked by Github Actions automatically. The history of these can be accessed [here](https://github.com/rosetta-models/digital-regulatory-reporting/actions/workflows/cve-scanning-schedule.yml), looking for 'DRR Model CVE Scanning'. The Dependency-Checker output is a CVE Scan Report, accessed under the 'Artifacts' heading.

Guidance for interpretation of the report can be found [here](https://dependency-check.github.io/DependencyCheck/general/thereport.html).

Note that new CVEs are added to the NVD continuously as they are discovered. This means CVE scan failures can begin to occur without source changes. It also means past releases of DRR, that had library dependencies thought secure at the time of release, could be found later to have library dependencies with vulnerabilities.