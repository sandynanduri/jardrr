Each of the Working Groups owns its roadmap, facilitated by the Chair. The Steering WG oversees the process and the integration across Working Groups.

<table>
  <tr>
    <th>Working Group<br />Chair</th>
    <th>1Q 2026</th>
    <th>2Q 2026</th>
    <th>3Q 2026</th>
    <th>4Q 2026</th>
  </tr>
  <tr>
    <td><b>Steering WG</b><br />David Shone</td>
    <td><ul>
        <li>Annual Review of governance</li>
        <li>Establish release schedule</li>
       <li>Agree 2026 roadmap</li>
       <li>Re-ratify TOM</li>
       <li>Agree objectives 2026+</li>
      </ul></td>
      <td><ul>
        <li>BAU </li>
      </ul></td>
      <td><ul>
        <li>BAU </li>
        <li>Nominations for Chair from Jan 2027 </li>
      </ul></td>
      <td><ul>
        <li>BAU </li>
        <li>Vote / appoint Chair from Jan 2027 </li>
        <li>Agree & publish Roadmap for 2027 </li>
      </ul></td>
     </tr>
    <tr>
    <td><b>ISDA DRR WG</b><br />Tabish Ahmed</td>
    <td><ul>
       <li>SEC</li>
       <li>SFTR (led by ISLA & ICMA)</li>     
       <li>Traceability Tool, RFQ decision</li>
       <li>ReportableInformation improvements</li>
       <li>DRR 7 production</li>       
      </ul></td>
      <td><ul>
        <li>SFTR (led by ISLA & ICMA)</li>
        <li>Strate</li>
        <li>Traceability Tool build</li>
        <li>ReportableInformation improvements</li>
      </ul></td>
      <td><ul>
        <li>SFTR (led by ISLA & ICMA)</li>
        <li>MiFiR EU build</li>
        <li>Strate</li>
        <li>Traceability Tool</li>
      </ul></td>
      <td><ul>
        <li>MiFiR EU UAT</li>
        <li>Traceability Tool</li>
      </ul></td>
     </tr>
</table>
  
