package com.regnosys.drr.projection.esma;

import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TestPackModel;
import com.regnosys.testing.transform.TransformTestExtension;
import drr.projection.unavista.esma.mifir.rewrite.trade.functions.Project_EsmaMifirTradeReportToUnavistaCSV;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.regnosys.rosetta.common.transform.TestPackUtils.PROJECTION_CONFIG_PATH;

public class EsmaMifirRts22TransactionReportToUnavistaCsvTest {
    
    @RegisterExtension
    static TransformTestExtension<Project_EsmaMifirTradeReportToUnavistaCSV> testExtension =
            new TransformTestExtension<>(
                    new ReportTestRuntimeModule(),
                    PROJECTION_CONFIG_PATH,
                    Project_EsmaMifirTradeReportToUnavistaCSV.class)
                    .withIncludeAllPipelinesForFunction(true);

    @ParameterizedTest(name = "{0}")
    @MethodSource("inputFiles")
    void runReport(String testName,
                   String testPackId,
                   TestPackModel.SampleModel sampleModel,
                   String pipelineId) {
        testExtension.runTransformAndAssert(pipelineId, testPackId, sampleModel);
    }

    private static Stream<Arguments> inputFiles() {
        return testExtension.getArguments();
    }
}
