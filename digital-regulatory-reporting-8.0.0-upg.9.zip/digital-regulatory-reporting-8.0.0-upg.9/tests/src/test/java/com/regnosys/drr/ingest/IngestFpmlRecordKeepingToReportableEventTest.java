package com.regnosys.drr.ingest;

import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TestPackModel;
import com.regnosys.testing.transform.TransformTestExtension;
import drr.ingest.fpml.recordkeeping.message.functions.Ingest_FpmlRecordKeepingToReportableEvent;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.regnosys.rosetta.common.transform.TestPackUtils.INGEST_CONFIG_PATH;

@Disabled
@TestInstance(TestInstance.Lifecycle.PER_CLASS)
public class IngestFpmlRecordKeepingToReportableEventTest {

    @RegisterExtension
    static TransformTestExtension<Ingest_FpmlRecordKeepingToReportableEvent> testExtension =
            new TransformTestExtension<>(
                    new ReportTestRuntimeModule(),
                    INGEST_CONFIG_PATH,
                    Ingest_FpmlRecordKeepingToReportableEvent.class);

    @ParameterizedTest(name = "{0}")
    @MethodSource("inputFiles")
    void runIngest(String testName,
                   String testPackId,
                   TestPackModel.SampleModel sampleModel) {
        testExtension.runTransformAndAssert(testPackId, sampleModel);
    }

    private static Stream<Arguments> inputFiles() {
        return testExtension.getArguments();
    }
}
