package com.regnosys.drr.testpack;

import com.google.common.base.Stopwatch;
import com.google.common.collect.ImmutableMap;
import com.google.inject.Injector;
import com.regnosys.drr.analytics.iso20022.ValidationSummaryMain;
import com.regnosys.drr.enrich.CFTCEventScenariosExampleSubmissionWorkflowTest;
import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TransformType;
import com.regnosys.runefpml.RuneFpmlModelConfig;
import com.regnosys.testing.TestingExpectationUtil;
import com.regnosys.testing.pipeline.PipelineConfigWriter;
import com.regnosys.testing.pipeline.PipelineFilter;
import com.regnosys.testing.pipeline.PipelineTreeConfig;
import com.rosetta.model.lib.functions.RosettaFunction;
import com.rosetta.model.lib.reports.ReportFunction;
import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackDefault;
import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackPreEnrich;
import drr.ingest.fpml.recordkeeping.message.functions.Ingest_FpmlRecordKeepingToReportableEvent;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.trade.functions.Project_CftcPart43TradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.trade.functions.Project_CftcPart45TradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.cftc.rewrite.valuation.functions.Project_CFTCValuationReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.trade.functions.Project_CSATradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.trade.functions.Project_CsaPpdReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.csa.rewrite.valuation.functions.Project_CSAValuationReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.sec.rewrite.trade.functions.Project_SECTradeReportToDtccRdsHarmonized;
import drr.projection.dtcc.rds.harmonized.sec.rewrite.trade.functions.Project_SecPpdReportToDtccRdsHarmonized;
import drr.projection.iso20022.asic.rewrite.margin.functions.Project_ASICMarginReportToIso20022;
import drr.projection.iso20022.asic.rewrite.trade.functions.Project_ASICTradeReportToIso20022;
import drr.projection.iso20022.asic.rewrite.valuation.functions.Project_ASICValuationReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.margin.functions.Project_EsmaEmirMarginReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.trade.functions.Project_EsmaEmirTradeReportToIso20022;
import drr.projection.iso20022.esma.emir.refit.valuation.functions.Project_EsmaEmirValuationReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.margin.functions.Project_FcaUkEmirMarginReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.trade.functions.Project_FcaUkEmirTradeReportToIso20022;
import drr.projection.iso20022.fca.ukemir.refit.valuation.functions.Project_FcaUkEmirValuationReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.margin.dtcc.functions.Project_HKMADtccMarginReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.margin.tr.functions.Project_HKMATrMarginReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.trade.dtcc.functions.Project_HKMADtccTradeReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.trade.tr.functions.Project_HKMATrTradeReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.valuation.dtcc.functions.Project_HKMADtccValuationReportToIso20022;
import drr.projection.iso20022.hkma.rewrite.valuation.tr.functions.Project_HKMATrValuationReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.margin.functions.Project_JFSARewriteMarginReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.trade.functions.Project_JFSARewriteTradeReportToIso20022;
import drr.projection.iso20022.jfsa.rewrite.valuation.functions.Project_JFSARewriteValuationReportToIso20022;
import drr.projection.iso20022.mas.rewrite.margin.functions.Project_MASMarginReportToIso20022;
import drr.projection.iso20022.mas.rewrite.trade.functions.Project_MASTradeReportToIso20022;
import drr.projection.iso20022.mas.rewrite.valuation.functions.Project_MASValuationReportToIso20022;
import drr.projection.marketaxess.esma.mifir.rewrite.transparency.functions.Project_EsmaMifirRts1TransparencyReportToMarketAxessFix;
import drr.projection.marketaxess.esma.mifir.rewrite.transparency.functions.Project_EsmaMifirRts2TransparencyReportToMarketAxessFix;
import drr.projection.unavista.esma.mifir.rewrite.trade.functions.Project_EsmaMifirTradeReportToUnavistaCSV;
import drr.regulation.asic.rewrite.margin.reports.ASICMarginReportFunction;
import drr.regulation.asic.rewrite.trade.reports.ASICTradeReportFunction;
import drr.regulation.asic.rewrite.valuation.reports.ASICValuationReportFunction;
import drr.regulation.cftc.rewrite.margin.reports.CFTCMarginReportFunction;
import drr.regulation.cftc.rewrite.trade.reports.CFTCPart43ReportFunction;
import drr.regulation.cftc.rewrite.trade.reports.CFTCPart45ReportFunction;
import drr.regulation.cftc.rewrite.valuation.reports.CFTCValuationReportFunction;
import drr.regulation.csa.rewrite.margin.reports.CSAMarginReportFunction;
import drr.regulation.csa.rewrite.trade.reports.CSAPPDReportFunction;
import drr.regulation.csa.rewrite.trade.reports.CSATradeReportFunction;
import drr.regulation.csa.rewrite.valuation.reports.CSAValuationReportFunction;
import drr.regulation.esma.emir.refit.margin.reports.ESMAEMIRMarginReportFunction;
import drr.regulation.esma.emir.refit.trade.reports.ESMAEMIRTradeReportFunction;
import drr.regulation.esma.emir.refit.valuation.reports.ESMAEMIRValuationReportFunction;
import drr.regulation.esma.mifir.rewrite.trade.reports.ESMAMIFIRRTS22ReportFunction;
import drr.regulation.esma.mifir.rewrite.transparency.rts1.reports.ESMAMIFIRRTS1ReportFunction;
import drr.regulation.esma.mifir.rewrite.transparency.rts2.reports.ESMAMIFIRRTS2ReportFunction;
import drr.regulation.fca.ukemir.refit.margin.reports.FCAUKEMIRMarginReportFunction;
import drr.regulation.fca.ukemir.refit.trade.reports.FCAUKEMIRTradeReportFunction;
import drr.regulation.fca.ukemir.refit.valuation.reports.FCAUKEMIRValuationReportFunction;
import drr.regulation.hkma.rewrite.margin.reports.HKMAMarginReportFunction;
import drr.regulation.hkma.rewrite.trade.reports.HKMATradeReportFunction;
import drr.regulation.hkma.rewrite.valuation.reports.HKMAValuationReportFunction;
import drr.regulation.jfsa.rewrite.margin.reports.JFSAMarginReportFunction;
import drr.regulation.jfsa.rewrite.trade.reports.JFSATradeReportFunction;
import drr.regulation.jfsa.rewrite.valuation.reports.JFSAValuationReportFunction;
import drr.regulation.mas.rewrite.margin.reports.MASMarginReportFunction;
import drr.regulation.mas.rewrite.trade.reports.MASTradeReportFunction;
import drr.regulation.mas.rewrite.valuation.reports.MASValuationReportFunction;
import drr.regulation.sec.rewrite.trade.reports.SECPPDReportFunction;
import drr.regulation.sec.rewrite.trade.reports.SECTradeReportFunction;
import fpml.consolidated.doc.Document;
import jakarta.inject.Inject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;

import static com.regnosys.testing.pipeline.PipelineFilter.startsWith;
import static iso20022.Iso20022ModelConfig.TYPE_TO_SCHEMA_MAP;
import static org.apache.commons.io.FileUtils.deleteDirectory;

public class DrrTestPackCreator {

    private static final Logger LOGGER = LoggerFactory.getLogger(DrrTestPackCreator.class);

    private static final Predicate<String> DEFAULT_ENRICH_TEST_PACKS = allExcept("exotic", "pre-enrich");
    private static final Predicate<String> PRE_ENRICH_TEST_PACK = PipelineFilter.equalsTo("pre-enrich");

    @Inject
    private PipelineConfigWriter pipelineConfigWriter;

    @Inject
    private CFTCEventScenariosExampleSubmissionWorkflowTest cftcEventScenariosExampleSubmissionWorkflowTest;

    @Inject
    private ValidationSummaryMain validationSummaryMain;

    /**
     * Regenerates DRR's ingest expectations and test packs, then exits with 0, or 1 if any step fails.
     */
    public static void main(String[] args) {
        try {
            DrrTestPackCreator testPackConfigCreator = new DrrTestPackCreator();

            setupInjector(testPackConfigCreator);

            Stopwatch t = Stopwatch.createStarted();
            //run clean to delete test packs to be regenerated NOT run for ING
            testPackConfigCreator.clean();

            // The CFTC workflow test builds its samples from function ingest output, so function ingest runs first. The
            // test reads that output from the classpath, i.e. as it was when rosetta-source was built
            testPackConfigCreator.runFunctionIngest();
            // Writes its samples into the ingest output folder, so it runs before generatePipelines, whose trade tree
            // enriches those samples with the rest
            testPackConfigCreator.runCFTCEventScenariosExampleSubmissionWorkflowTest();

            testPackConfigCreator.generatePipelines();

            //testPackConfigCreator.runValidationSummary();

            LOGGER.info("DRR pipeline / test pack update took {}", t);

            System.exit(0);
        } catch (Exception e) {
            LOGGER.error("Error executing {}.main()", DrrTestPackCreator.class.getName(), e);
            System.exit(1);
        }
    }

    private static void setupInjector(DrrTestPackCreator drrTestPackCreator) {
        Injector injector = new ReportTestRuntimeModule.InjectorProvider().getInjector();
        injector.injectMembers(drrTestPackCreator);
    }

    private void clean() throws IOException {
        Path path = TestingExpectationUtil.TEST_WRITE_BASE_PATH.get();
        // These will all get regenerated by the PipelineConfigWriter
        deleteDirectory(path.resolve("ingest/config").toFile());
        deleteDirectory(path.resolve("ingest/output").toFile());
        deleteDirectory(path.resolve("enrich").toFile());
        //deleteDirectory(path.resolve("regulatory-reporting/config").toFile());
        //deleteDirectory(path.resolve("regulatory-reporting/output").toFile());
        //deleteDirectory(path.resolve("projection").toFile());
    }

    /**
     * Generates the function ingest test packs ahead of the CFTC workflow test. The trade tree ingests the same samples
     * again.
     */
    private void runFunctionIngest() throws IOException {
        pipelineConfigWriter.writePipelinesAndTestPacks(getFunctionIngestConfig());
    }

    private PipelineTreeConfig getFunctionIngestConfig() {
        PipelineTreeConfig pipelineConfig = new PipelineTreeConfig()
                .starting(TransformType.TRANSLATE, Ingest_FpmlRecordKeepingToReportableEvent.class);
        return addXMLAndSchemaMap(pipelineConfig);
    }

    private void runCFTCEventScenariosExampleSubmissionWorkflowTest() throws Exception {
        LOGGER.info(" ** Updating expectations for cftcEventScenariosExampleSubmissionWorkflowTest");
        cftcEventScenariosExampleSubmissionWorkflowTest.updateExpectations();
    }

    private void runValidationSummary() throws Exception {
        LOGGER.info("** Updating expectations for validationSummaryTest");
        validationSummaryMain.run();
    }

    /**
     * Generates the test packs of every pipeline: the trade tree (see {@link #getTradeConfig()}), the valuation trees
     * and the collateral tree.
     */
    private void generatePipelines() throws IOException {
        pipelineConfigWriter.writePipelinesAndTestPacks(getTradeConfig());

        pipelineConfigWriter.writePipelinesAndTestPacks(createASICValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createCSAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createCFTCValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createESMAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createFCAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createHKMAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createJFSAValuationTreeConfig(startsWith("valuation")));
        pipelineConfigWriter.writePipelinesAndTestPacks(createMASValuationTreeConfig(startsWith("valuation")));

        pipelineConfigWriter.writePipelinesAndTestPacks(createCollateralTreeConfig(startsWith("collateral")));
    }

    // Trade

    private static final List<TradeReport> TRADE_REPORTS = List.of(
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), ASICTradeReportFunction.class, List.of(Project_ASICTradeReportToIso20022.class)),
            new TradeReport(allExcept("commodity", "delegated-reporting", "etd"), CFTCPart43ReportFunction.class, List.of(Project_CftcPart43TradeReportToDtccRdsHarmonized.class)),
            new TradeReport(allExcept("commodity", "delegated-reporting", "etd"), CFTCPart45ReportFunction.class, List.of(Project_CftcPart45TradeReportToDtccRdsHarmonized.class)),
            new TradeReport(allExcept("delegated-reporting", "etd"), CSAPPDReportFunction.class, List.of(Project_CsaPpdReportToDtccRdsHarmonized.class)),
            new TradeReport(allExcept("delegated-reporting", "etd"), CSATradeReportFunction.class, List.of(Project_CSATradeReportToDtccRdsHarmonized.class)),
            new TradeReport(allExcept("cftc-event-scenarios"), ESMAEMIRTradeReportFunction.class, List.of(Project_EsmaEmirTradeReportToIso20022.class)),
            new TradeReport(allExcept("cftc-event-scenarios"), ESMAMIFIRRTS1ReportFunction.class, List.of(Project_EsmaMifirRts1TransparencyReportToMarketAxessFix.class)),
            new TradeReport(allExcept("cftc-event-scenarios"), ESMAMIFIRRTS2ReportFunction.class, List.of(Project_EsmaMifirRts2TransparencyReportToMarketAxessFix.class)),
            new TradeReport(allExcept("cftc-event-scenarios"), ESMAMIFIRRTS22ReportFunction.class, List.of(Project_EsmaMifirTradeReportToUnavistaCSV.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "commodity", "delegated-reporting", "etd"), FCAUKEMIRTradeReportFunction.class, List.of(Project_FcaUkEmirTradeReportToIso20022.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), HKMATradeReportFunction.class, List.of(Project_HKMADtccTradeReportToIso20022.class, Project_HKMATrTradeReportToIso20022.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), JFSATradeReportFunction.class, List.of(Project_JFSARewriteTradeReportToIso20022.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), MASTradeReportFunction.class, List.of(Project_MASTradeReportToIso20022.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), SECTradeReportFunction.class, List.of(Project_SECTradeReportToDtccRdsHarmonized.class)),
            new TradeReport(allExcept("cftc-event-scenarios", "delegated-reporting", "etd"), SECPPDReportFunction.class, List.of(Project_SecPpdReportToDtccRdsHarmonized.class)));

    /**
     * All trade pipelines in one tree, so each enrich, report and projection function is only executed once per sample
     * (ingest also runs once before the tree, in {@link #runFunctionIngest()}).
     * Each report is fed by both the default enrich (restricted to that report's test packs) and the pre-enrich enrich
     * (restricted to the pre-enrich test pack).
     */
    private PipelineTreeConfig getTradeConfig() {
        final PipelineTreeConfig pipelineConfig = new PipelineTreeConfig()
                .starting(TransformType.TRANSLATE, Ingest_FpmlRecordKeepingToReportableEvent.class)
                .add(Ingest_FpmlRecordKeepingToReportableEvent.class, TransformType.ENRICH, Enrich_TransactionReportInstructionTestPackDefault.class, DEFAULT_ENRICH_TEST_PACKS)
                .add(Ingest_FpmlRecordKeepingToReportableEvent.class, TransformType.ENRICH, Enrich_TransactionReportInstructionTestPackPreEnrich.class, PRE_ENRICH_TEST_PACK);

        //TRADE_REPORTS.forEach(r -> addTradeReport(pipelineConfig, r));

        return addXMLAndSchemaMap(pipelineConfig);
    }

    /**
     * Accepts every test pack except those starting with the given names, so a new test pack folder reaches a report
     * unless it is excluded.
     */
    private static Predicate<String> allExcept(String... testPacks) {
        return startsWith(testPacks).negate();
    }

    /**
     * Adds a trade report under both enrich steps, and its projections under the report. Under the default enrich the
     * report is restricted to its own test packs; under the pre-enrich enrich it inherits that step's filter.
     */
    private void addTradeReport(PipelineTreeConfig pipelineConfig, TradeReport tradeReport) {
        pipelineConfig
                .add(Enrich_TransactionReportInstructionTestPackDefault.class, TransformType.REPORT, tradeReport.reportFunc, tradeReport.testPackFilter)
                .add(Enrich_TransactionReportInstructionTestPackPreEnrich.class, TransformType.REPORT, tradeReport.reportFunc);
        tradeReport.projectionFuncs.forEach(projectionFunc -> pipelineConfig.add(tradeReport.reportFunc, TransformType.PROJECTION, projectionFunc));
    }

    /**
     * One trade report in the trade tree: the test packs it runs under the default enrich, the report function, and the
     * projections that read its output.
     */
    private static final class TradeReport {

        private final Predicate<String> testPackFilter;
        private final Class<? extends ReportFunction<?, ?>> reportFunc;
        private final List<Class<? extends RosettaFunction>> projectionFuncs;

        private TradeReport(Predicate<String> testPackFilter,
                            Class<? extends ReportFunction<?, ?>> reportFunc,
                            List<Class<? extends RosettaFunction>> projectionFuncs) {
            this.testPackFilter = testPackFilter;
            this.reportFunc = reportFunc;
            this.projectionFuncs = projectionFuncs;
        }
    }

    // Valuation

    private PipelineTreeConfig createASICValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig asicValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, ASICValuationReportFunction.class)
                .add(ASICValuationReportFunction.class, TransformType.PROJECTION, Project_ASICValuationReportToIso20022.class);

        return addXMLAndSchemaMap(asicValuationConfig);
    }

    public PipelineTreeConfig createCSAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig csaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CSAValuationReportFunction.class)
                .add(CSAValuationReportFunction.class, TransformType.PROJECTION, Project_CSAValuationReportToDtccRdsHarmonized.class);

        return addXMLAndSchemaMap(csaValuationConfig);
    }

    private PipelineTreeConfig createCFTCValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig cftcValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CFTCValuationReportFunction.class)
                .add(CFTCValuationReportFunction.class, TransformType.PROJECTION, Project_CFTCValuationReportToDtccRdsHarmonized.class);

        return addXMLAndSchemaMap(cftcValuationConfig);
    }

    private PipelineTreeConfig createESMAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig esmaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)
                .starting(TransformType.REPORT, ESMAEMIRValuationReportFunction.class)
                .add(ESMAEMIRValuationReportFunction.class, TransformType.PROJECTION, Project_EsmaEmirValuationReportToIso20022.class);
        return addXMLAndSchemaMap(esmaValuationConfig);
    }

    private PipelineTreeConfig createFCAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig fcaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)
                .starting(TransformType.REPORT, FCAUKEMIRValuationReportFunction.class)
                .add(FCAUKEMIRValuationReportFunction.class, TransformType.PROJECTION, Project_FcaUkEmirValuationReportToIso20022.class);
        return addXMLAndSchemaMap(fcaValuationConfig);
    }

    public PipelineTreeConfig createHKMAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig hkmaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, HKMAValuationReportFunction.class)
                .add(HKMAValuationReportFunction.class, TransformType.PROJECTION, Project_HKMATrValuationReportToIso20022.class)
                .add(HKMAValuationReportFunction.class, TransformType.PROJECTION, Project_HKMADtccValuationReportToIso20022.class);

        return addXMLAndSchemaMap(hkmaValuationConfig);
    }

    private PipelineTreeConfig createJFSAValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig jfsaValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, JFSAValuationReportFunction.class)
                .add(JFSAValuationReportFunction.class, TransformType.PROJECTION, Project_JFSARewriteValuationReportToIso20022.class);

        return addXMLAndSchemaMap(jfsaValuationConfig);
    }

    public PipelineTreeConfig createMASValuationTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig masValuationConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, MASValuationReportFunction.class)
                .add(MASValuationReportFunction.class, TransformType.PROJECTION, Project_MASValuationReportToIso20022.class);

        return addXMLAndSchemaMap(masValuationConfig);
    }

    // Collateral

    /**
     * The collateral (margin) reports and their projections, for the test packs the filter accepts. Each report is a
     * starting function, configured once.
     */
    private PipelineTreeConfig createCollateralTreeConfig(Predicate<String> testPackIdInclusionFilter) {
        final PipelineTreeConfig collateralTreeConfig = new PipelineTreeConfig()
                .withTestPackIdFilter(testPackIdInclusionFilter)

                .starting(TransformType.REPORT, CFTCMarginReportFunction.class)

                .starting(TransformType.REPORT, ASICMarginReportFunction.class)
                .add(ASICMarginReportFunction.class, TransformType.PROJECTION, Project_ASICMarginReportToIso20022.class)

                .starting(TransformType.REPORT, CSAMarginReportFunction.class)

                .starting(TransformType.REPORT, ESMAEMIRMarginReportFunction.class)
                .add(ESMAEMIRMarginReportFunction.class, TransformType.PROJECTION, Project_EsmaEmirMarginReportToIso20022.class)

                .starting(TransformType.REPORT, FCAUKEMIRMarginReportFunction.class)
                .add(FCAUKEMIRMarginReportFunction.class, TransformType.PROJECTION, Project_FcaUkEmirMarginReportToIso20022.class)

                .starting(TransformType.REPORT, JFSAMarginReportFunction.class)
                .add(JFSAMarginReportFunction.class, TransformType.PROJECTION, Project_JFSARewriteMarginReportToIso20022.class)

                .starting(TransformType.REPORT, MASMarginReportFunction.class)
                .add(MASMarginReportFunction.class, TransformType.PROJECTION, Project_MASMarginReportToIso20022.class)

                .starting(TransformType.REPORT, HKMAMarginReportFunction.class)
                .add(HKMAMarginReportFunction.class, TransformType.PROJECTION, Project_HKMADtccMarginReportToIso20022.class)
                .add(HKMAMarginReportFunction.class, TransformType.PROJECTION, Project_HKMATrMarginReportToIso20022.class);

        return addXMLAndSchemaMap(collateralTreeConfig);
    }

    private PipelineTreeConfig addXMLAndSchemaMap(PipelineTreeConfig pipelineTreeConfig) {
        ImmutableMap<Class<?>, String> fpmlTypeToSchemaMap = ImmutableMap.<Class<?>, String>builder()
                .put(Document.class, RuneFpmlModelConfig.FPML_RECORDKEEPING_SCHEMA_PATH)
                .build();

        return pipelineTreeConfig
                .withXmlSchemaMap(mergeMaps(fpmlTypeToSchemaMap, TYPE_TO_SCHEMA_MAP))
                .strictUniqueIds();
    }

    private static <T> ImmutableMap<Class<?>, T> mergeMaps(Map<Class<?>, ? extends T> map1, Map<Class<?>, ? extends T> map2) {
        return ImmutableMap.<Class<?>, T>builder()
                .putAll(map1)
                .putAll(map2)
                .build();
    }
}
