package com.regnosys.drr.dataquality.runner;
// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)

import com.regnosys.drr.dataquality.TestPackModifier;
import com.regnosys.drr.dataquality.modifiers.ModifierContext;

import java.util.List;

public interface TestPackModifierFactory {
    List<TestPackModifier> getTestPackModifierModifiers(ModifierContext context);
}
