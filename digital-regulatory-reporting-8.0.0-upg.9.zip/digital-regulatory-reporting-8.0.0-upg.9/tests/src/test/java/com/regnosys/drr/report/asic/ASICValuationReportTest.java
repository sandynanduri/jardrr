// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)
//package com.regnosys.drr.report.asic;
//
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.regulation.asic.rewrite.valuation.reports.ASICValuationReportFunction;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.util.stream.Stream;
//
//import static com.regnosys.rosetta.common.transform.TestPackUtils.REPORT_CONFIG_PATH;
//
//public class ASICValuationReportTest {
//
//    @RegisterExtension
//    static TransformTestExtension<ASICValuationReportFunction> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    REPORT_CONFIG_PATH,
//                    ASICValuationReportFunction.class);
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runReport(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel) {
//        testExtension.runTransformAndAssert(testPackId, sampleModel);
//    }
//
//    @SuppressWarnings("unused")//used by the junit parameterized test
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
