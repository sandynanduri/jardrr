//package com.regnosys.drr.report.jfsa;
//
//import com.google.common.io.Resources;
//import com.google.inject.Injector;
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.serialisation.RosettaObjectMapper;
//import drr.base.qualification.event.functions.IsActionTypeMODI;
//import drr.base.qualification.event.functions.IsActionTypeNEWT;
//import drr.base.qualification.event.functions.IsActionTypeTERM;
//import drr.regulation.common.TransactionReportInstruction;
//import drr.regulation.jfsa.rewrite.trade.reports.EventIdentifierRule;
//import drr.standards.iosco.cde.version3.event.reports.EventTypeRule;
//import drr.standards.iso.EventTypeEnum;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.ValueSource;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//import static org.junit.jupiter.api.Assertions.assertNull;
//
///**
// * Verifies the JFSA Event Identifier reporting rule guard added per Rewrite Spec v1.1 row 138.
// * The rule must only extract an identifier when:
// *   - Event Type = COMP and Action Type ∈ {NEWT, MODI, TERM}, or
// *   - Event Type = CREV and Action Type ∈ {MODI, TERM}.
// * For any other combination (notably NEWT + CLRG) it must return null so the optional
// * Max52AlphaNumericText field remains absent and does not fail pattern validation.
// */
//class JFSAEventIdentifierRuleTest {
//
//    private static final String SAMPLES_ROOT =
//            "/enrich/output/fpml-record-keeping-to-reportable-event/transaction-report-instruction-test-pack-default/events/";
//
//    private static EventIdentifierRule eventIdentifierRule;
//    private static EventTypeRule eventTypeRule;
//    private static IsActionTypeNEWT isActionTypeNEWT;
//    private static IsActionTypeMODI isActionTypeMODI;
//    private static IsActionTypeTERM isActionTypeTERM;
//
//    @BeforeAll
//    static void setup() {
//        Injector injector = new ReportTestRuntimeModule.InjectorProvider().getInjector();
//        eventIdentifierRule = injector.getInstance(EventIdentifierRule.class);
//        eventTypeRule = injector.getInstance(EventTypeRule.class);
//        isActionTypeNEWT = injector.getInstance(IsActionTypeNEWT.class);
//        isActionTypeMODI = injector.getInstance(IsActionTypeMODI.class);
//        isActionTypeTERM = injector.getInstance(IsActionTypeTERM.class);
//    }
//
//    /**
//     * Property-based assertion over existing JFSA input samples: the identifier must be
//     * non-null only when the spec-required action/event pair is satisfied, and null otherwise.
//     * This catches the original NEWT+CLRG regression and any future combination that would
//     * populate the field outside the spec's required set.
//     */
//    @ParameterizedTest(name = "{0}")
//    @ValueSource(strings = {
//            "Clearing-new-alpha-Trade-02.json",
//            "Clearing-cleared-alpha-Trade-03.json",
//            "Clearing-cleared-beta-Trade-04.json",
//            "New-Trade-01.json",
//            "Trade-Correction-ex01.json",
//            "Trade-Modify-Amendment.json",
//            "Trade-Modify-Partial-Termination-ex-01.json"
//    })
//    void eventIdentifierIsPresentOnlyWhenSpecConditionsAreSatisfied(String sampleFile) throws IOException {
//        TransactionReportInstruction input = loadSample(sampleFile);
//
//        EventTypeEnum eventType = eventTypeRule.evaluate(input);
//        boolean isNEWT = Boolean.TRUE.equals(isActionTypeNEWT.evaluate(input));
//        boolean isMODI = Boolean.TRUE.equals(isActionTypeMODI.evaluate(input));
//        boolean isTERM = Boolean.TRUE.equals(isActionTypeTERM.evaluate(input));
//
//        boolean required = (eventType == EventTypeEnum.COMP && (isNEWT || isMODI || isTERM))
//                || (eventType == EventTypeEnum.CREV && (isMODI || isTERM));
//
//        String identifier = eventIdentifierRule.evaluate(input);
//
//        if (required) {
//            assertNotNull(identifier,
//                    "Expected eventIdentifier for eventType=" + eventType
//                            + ", NEWT=" + isNEWT + ", MODI=" + isMODI + ", TERM=" + isTERM);
//        } else {
//            assertNull(identifier,
//                    "eventIdentifier must be null when spec conditions are not met (eventType="
//                            + eventType + ", NEWT=" + isNEWT + ", MODI=" + isMODI + ", TERM=" + isTERM
//                            + "), but was '" + identifier + "'");
//        }
//    }
//
//    private TransactionReportInstruction loadSample(String sampleFile) throws IOException {
//        String json = Resources.toString(
//                java.util.Objects.requireNonNull(getClass().getResource(SAMPLES_ROOT + sampleFile),
//                        "Sample not found: " + SAMPLES_ROOT + sampleFile),
//                StandardCharsets.UTF_8);
//        return RosettaObjectMapper.getNewRosettaObjectMapper()
//                .readValue(json, TransactionReportInstruction.class);
//    }
//}
