//package com.regnosys.drr.enrich;
//
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.rosetta.common.transform.TransformType;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.enrichment.common.test.functions.Enrich_TransactionReportInstructionTestPackDefault;
//import org.junit.jupiter.api.TestInstance;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.nio.file.Path;
//import java.nio.file.Paths;
//import java.util.stream.Stream;
//
//@TestInstance(TestInstance.Lifecycle.PER_CLASS)
//public class EnrichTransactionReportInstructionTestPackDefaultTest {
//
//    public static final Path ENRICH_CONFIG_PATH = Paths.get(TransformType.ENRICH.getResourcePath()).resolve("config");
//
//    @RegisterExtension
//    static TransformTestExtension<Enrich_TransactionReportInstructionTestPackDefault> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    ENRICH_CONFIG_PATH,
//                    Enrich_TransactionReportInstructionTestPackDefault.class);
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runIngest(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel) {
//        testExtension.runTransformAndAssert(testPackId, sampleModel);
//    }
//
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
//
//
