// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)
//package com.regnosys.drr.report.sec;
//
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.regulation.sec.rewrite.trade.reports.SECTradeReportFunction;
//import org.junit.jupiter.api.Disabled;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.util.stream.Stream;
//
//import static com.regnosys.rosetta.common.transform.TestPackUtils.REPORT_CONFIG_PATH;
//
//public class SECTradeReportTest {
//
//    @RegisterExtension
//    static TransformTestExtension<SECTradeReportFunction> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    REPORT_CONFIG_PATH,
//                    SECTradeReportFunction.class)
//                    .withIncludeAllPipelinesForFunction(true);
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runReport(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel,
//                   String pipelineId) {
//        testExtension.runTransformAndAssert(pipelineId, testPackId, sampleModel);
//    }
//
//    @SuppressWarnings("unused")//used by the junit parameterized test
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
//
