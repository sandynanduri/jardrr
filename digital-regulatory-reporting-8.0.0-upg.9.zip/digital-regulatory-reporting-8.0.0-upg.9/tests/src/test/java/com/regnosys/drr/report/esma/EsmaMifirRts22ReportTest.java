//package com.regnosys.drr.report.esma;
//
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.regulation.esma.mifir.rewrite.trade.reports.ESMAMIFIRRTS22ReportFunction;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.util.stream.Stream;
//
//import static com.regnosys.rosetta.common.transform.TestPackUtils.REPORT_CONFIG_PATH;
//
//public class EsmaMifirRts22ReportTest {
//
//    @RegisterExtension
//    static TransformTestExtension<ESMAMIFIRRTS22ReportFunction> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    REPORT_CONFIG_PATH,
//                    ESMAMIFIRRTS22ReportFunction.class)
//                    .withIncludeAllPipelinesForFunction(true);
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runReport(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel,
//                   String pipelineId) {
//        testExtension.runTransformAndAssert(pipelineId, testPackId, sampleModel);
//    }
//
//    @SuppressWarnings("unused")//used by the junit parameterized test
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
