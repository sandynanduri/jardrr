//package com.regnosys.drr.report.cftc;
//
//import cdm.base.staticdata.party.PartyRoleEnum;
//import cdm.base.staticdata.party.RelatedParty;
//import cdm.event.common.BusinessEvent;
//import cdm.event.common.EventIntentEnum;
//import cdm.event.workflow.WorkflowState;
//import cdm.event.workflow.WorkflowStatusEnum;
//import cdm.event.workflow.WorkflowStep;
//import com.google.common.io.Resources;
//import com.google.inject.Injector;
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.serialisation.RosettaObjectMapper;
//import drr.base.qualification.event.functions.IsActionTypeTERM;
//import drr.base.trade.PartyInformation;
//import drr.regulation.common.SupervisoryBodyEnum;
//import drr.regulation.common.TransactionReportInstruction;
//import drr.regulation.common.dtcc.trade.functions.DTCC_SEFOrDCMAnonymousExecutionIndicator;
//import drr.standards.iosco.cde.version3.event.reports.EventTypeRule;
//import drr.standards.iso.EventTypeEnum;
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//
//import java.io.IOException;
//import java.nio.charset.StandardCharsets;
//import java.util.List;
//import java.util.Objects;
//import java.util.stream.Collectors;
//
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertNotNull;
//
///**
// * Regression test for the DTCC SEF or DCM Anonymous Execution Indicator function.
// * <p>
// * Per the DTCC GTR NoA Message Specification v3.3 (rs2151), row 225 of the
// * `NoA OTC Specification` sheet, the business rule is:
// * <pre>
// *   SEF and DCM: Required
// *   CCP and DCO: Required when [NoA - Action Type] = 'TERM' and
// *                ([Event Type] = 'CLRG' or = 'CLAL')
// *   NACK for all other submissions.
// * </pre>
// * Applies to CFTC, SEC, and Canada (per row 225's "Applicable to..." columns).
// * <p>
// * A prior implementation added a spec-unbacked {@code and centralCounterparty exists}
// * clause to the CCP/DCO branch of {@code DTCC_SEFOrDCMAnonymousExecutionIndicator}
// * (and its jurisdictional siblings). That clause caused the field to return null on
// * legitimate CCP/DCO submissions where the CDM data did not have centralCounterparty
// * populated - producing DTCC-side NACKs in JSCC's production reporting.
// * <p>
// * <b>Regression detection strategy:</b> DRR's test corpus contains no sample that
// * naturally satisfies both {@code IsActionTypeTERM=true} and {@code EventType=CLRG}
// * or {@code CLAL} - the exact combination the bug affects. This test builds that
// * state synthetically from an existing CLRG sample by:
// * <ol>
// *   <li>Setting {@code businessEvent.intent = EARLY_TERMINATION_PROVISION} so
// *       {@code IsActionTypeTERM} evaluates to true.</li>
// *   <li>Setting {@code workflowState.workflowStatus = CLEARED} so the CDE EventType
// *       rule's CLRG branch fires before the ETRM branch.</li>
// *   <li>Stripping any {@code CLEARING_ORGANIZATION}-role RelatedParty from
// *       {@code reportableInformation.globalPartyInformation[].relatedParty[]}, so
// *       {@code CentralCounterparty} resolves to absent - the CDM state that
// *       triggered the bug in production.</li>
// * </ol>
// * After the three mutations, the function must return a non-null indicator. If a
// * future refactor reintroduces the {@code centralCounterparty exists} clause to the
// * CCP/DCO branch, the mutated input would fall through to the ELSE branch (which
// * expects an ExecutionFacility-role reporting party, which our sample doesn't have)
// * and return null - failing the assertion.
// */
//class DtccSefOrDcmAnonymousExecutionIndicatorTest {
//
//    private static final String SAMPLE_PATH =
//            "/enrich/output/fpml-record-keeping-to-reportable-event/transaction-report-instruction-test-pack-default/cftc-event-scenarios/Example-06-Submission-2.json";
//
//    private static DTCC_SEFOrDCMAnonymousExecutionIndicator function;
//    private static EventTypeRule eventTypeRule;
//    private static IsActionTypeTERM isActionTypeTERM;
//
//    @BeforeAll
//    static void setup() {
//        Injector injector = new ReportTestRuntimeModule.InjectorProvider().getInjector();
//        function = injector.getInstance(DTCC_SEFOrDCMAnonymousExecutionIndicator.class);
//        eventTypeRule = injector.getInstance(EventTypeRule.class);
//        isActionTypeTERM = injector.getInstance(IsActionTypeTERM.class);
//    }
//
//    @Test
//    void indicatorIsNonNullOnSyntheticTermClrgWithoutCentralCounterparty() throws IOException {
//        TransactionReportInstruction synthetic = buildSyntheticTermClrgWithoutCcp();
//
//        // Precondition assertions: confirm the synthetic input actually satisfies the CCP/DCO
//        // branch of the DTCC v3.3 row 225 rule. If any of these fail, the mutation logic below
//        // has drifted from what the CDE rules read - the test is broken, not the fix.
//        assertEquals(Boolean.TRUE, isActionTypeTERM.evaluate(synthetic),
//                "Synthetic input must resolve to Action Type = TERM.");
//        assertEquals(EventTypeEnum.CLRG, eventTypeRule.evaluate(synthetic),
//                "Synthetic input must resolve to Event Type = CLRG.");
//
//        Boolean result = function.evaluate(synthetic, SupervisoryBodyEnum.CFTC);
//
//        assertNotNull(result,
//                "DTCC v3.3 spec row 225 requires the SEF/DCM Anonymous Execution Indicator to"
//                        + " be populated when Action Type = TERM and Event Type in (CLRG, CLAL)"
//                        + " - regardless of whether CentralCounterparty is resolvable from the CDM."
//                        + " Function returned null after CentralCounterparty was made unresolvable."
//                        + " This regression indicates the spec-unbacked"
//                        + " 'and centralCounterparty exists' clause has been reintroduced.");
//    }
//
//    /**
//     * Loads Example-06-Submission-2 and applies three mutations to produce a CDM state
//     * that exercises the DTCC v3.3 row 225 CCP/DCO branch with CentralCounterparty absent.
//     * See class-level javadoc for the mutation rationale.
//     */
//    private TransactionReportInstruction buildSyntheticTermClrgWithoutCcp() throws IOException {
//        TransactionReportInstruction input = loadSample();
//        TransactionReportInstruction.TransactionReportInstructionBuilder builder = input.toBuilder();
//
//        // Mutation 1: intent = EARLY_TERMINATION_PROVISION so IsActionTypeTERM returns true.
//        BusinessEvent.BusinessEventBuilder businessEvent = builder
//                .getOrCreateOriginatingWorkflowStep()
//                .getOrCreateBusinessEvent();
//        businessEvent.setIntent(EventIntentEnum.EARLY_TERMINATION_PROVISION);
//
//        // Mutation 2: workflowStatus = CLEARED so the CDE EventType rule fires CLRG before ETRM.
//        WorkflowStep.WorkflowStepBuilder workflowStep = builder.getOrCreateOriginatingWorkflowStep();
//        WorkflowState.WorkflowStateBuilder workflowState = workflowStep.getOrCreateWorkflowState();
//        workflowState.setWorkflowStatus(WorkflowStatusEnum.CLEARED);
//
//        // Mutation 3: remove every ClearingOrganization-role RelatedParty from
//        // reportableInformation.globalPartyInformation[].relatedParty[] - the exact path
//        // that CentralCounterpartyRule reads via ExtractPartyFromRelatedPartyByRole.
//        List<? extends PartyInformation.PartyInformationBuilder> partyInfos = builder
//                .getOrCreateReportableInformation()
//                .getGlobalPartyInformation();
//        for (PartyInformation.PartyInformationBuilder partyInfo : partyInfos) {
//            List<RelatedParty> filtered = partyInfo.getRelatedParty().stream()
//                    .filter(rp -> rp.getRole() != PartyRoleEnum.CLEARING_ORGANIZATION)
//                    .map(RelatedParty.RelatedPartyBuilder::build)
//                    .collect(Collectors.toList());
//            partyInfo.setRelatedParty(filtered);
//        }
//
//        return builder.build();
//    }
//
//    private TransactionReportInstruction loadSample() throws IOException {
//        String json = Resources.toString(
//                Objects.requireNonNull(getClass().getResource(SAMPLE_PATH),
//                        "Sample not found: " + SAMPLE_PATH),
//                StandardCharsets.UTF_8);
//        return RosettaObjectMapper.getNewRosettaObjectMapper()
//                .readValue(json, TransactionReportInstruction.class);
//    }
//}
