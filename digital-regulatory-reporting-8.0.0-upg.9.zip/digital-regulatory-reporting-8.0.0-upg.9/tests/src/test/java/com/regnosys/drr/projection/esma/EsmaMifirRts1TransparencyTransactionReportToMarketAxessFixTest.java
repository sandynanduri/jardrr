package com.regnosys.drr.projection.esma;

import com.regnosys.drr.report.ReportTestRuntimeModule;
import com.regnosys.rosetta.common.transform.TestPackModel;
import com.regnosys.testing.transform.TransformTestExtension;
import drr.projection.marketaxess.esma.mifir.rewrite.transparency.functions.Project_EsmaMifirRts1TransparencyReportToMarketAxessFix;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.stream.Stream;

import static com.regnosys.rosetta.common.transform.TestPackUtils.PROJECTION_CONFIG_PATH;

public class EsmaMifirRts1TransparencyTransactionReportToMarketAxessFixTest {
    
    @RegisterExtension
    static TransformTestExtension<Project_EsmaMifirRts1TransparencyReportToMarketAxessFix> testExtension =
            new TransformTestExtension<>(
                    new ReportTestRuntimeModule(),
                    PROJECTION_CONFIG_PATH,
                    Project_EsmaMifirRts1TransparencyReportToMarketAxessFix.class)
                    .withIncludeAllPipelinesForFunction(true);

    @ParameterizedTest(name = "{0}")
    @MethodSource("inputFiles")
    void runReport(String testName,
                   String testPackId,
                   TestPackModel.SampleModel sampleModel,
                   String pipelineId) {
        testExtension.runTransformAndAssert(pipelineId, testPackId, sampleModel);
    }

    private static Stream<Arguments> inputFiles() {
        return testExtension.getArguments();
    }
}
