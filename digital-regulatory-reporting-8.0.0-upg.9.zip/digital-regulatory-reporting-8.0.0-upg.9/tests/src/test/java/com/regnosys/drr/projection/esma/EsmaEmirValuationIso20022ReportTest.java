// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)
//package com.regnosys.drr.projection.esma;
//
//import com.google.common.io.Resources;
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.projection.iso20022.esma.emir.refit.margin.functions.Project_EsmaEmirMarginReportToIso20022;
//import drr.projection.iso20022.esma.emir.refit.valuation.functions.Project_EsmaEmirValuationReportToIso20022;
//import iso20022.Auth030EsmaModelConfig;
//import iso20022.Auth108EsmaModelConfig;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.util.stream.Stream;
//
//import static com.regnosys.rosetta.common.transform.TestPackUtils.PROJECTION_CONFIG_PATH;
//
//public class EsmaEmirValuationIso20022ReportTest {
//    @RegisterExtension
//    static TransformTestExtension<Project_EsmaEmirValuationReportToIso20022> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    PROJECTION_CONFIG_PATH,
//                    Project_EsmaEmirValuationReportToIso20022.class)
//                    .withSchemaValidation(Resources.getResource(Auth030EsmaModelConfig.SCHEMA_PATH));
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runReport(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel) {
//        testExtension.runTransformAndAssert(testPackId, sampleModel);
//    }
//
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
//
