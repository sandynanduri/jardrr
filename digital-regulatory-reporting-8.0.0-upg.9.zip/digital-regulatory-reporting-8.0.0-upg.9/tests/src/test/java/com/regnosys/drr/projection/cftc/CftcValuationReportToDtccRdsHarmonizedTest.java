// CDM7-DISABLED: body commented out for CDM7/DSL10 migration (uncomment to restore)
//package com.regnosys.drr.projection.cftc;
//
//import com.google.common.io.Resources;
//import com.regnosys.drr.report.ReportTestRuntimeModule;
//import com.regnosys.rosetta.common.transform.TestPackModel;
//import com.regnosys.testing.transform.TransformTestExtension;
//import drr.projection.dtcc.rds.harmonized.cftc.rewrite.trade.functions.Project_CftcPart43TradeReportToDtccRdsHarmonized;
//import drr.projection.dtcc.rds.harmonized.cftc.rewrite.valuation.functions.Project_CFTCValuationReportToDtccRdsHarmonized;
//import iso20022.DtccRdsHarmonizedModelConfig;
//import org.junit.jupiter.api.extension.RegisterExtension;
//import org.junit.jupiter.params.ParameterizedTest;
//import org.junit.jupiter.params.provider.Arguments;
//import org.junit.jupiter.params.provider.MethodSource;
//
//import java.util.stream.Stream;
//
//import static com.regnosys.rosetta.common.transform.TestPackUtils.PROJECTION_CONFIG_PATH;
//
//public class CftcValuationReportToDtccRdsHarmonizedTest {
//    @RegisterExtension
//    static TransformTestExtension<Project_CFTCValuationReportToDtccRdsHarmonized> testExtension =
//            new TransformTestExtension<>(
//                    new ReportTestRuntimeModule(),
//                    PROJECTION_CONFIG_PATH,
//                    Project_CFTCValuationReportToDtccRdsHarmonized.class)
//                    .withSchemaValidation(Resources.getResource(DtccRdsHarmonizedModelConfig.SCHEMA_PATH));
//
//    @ParameterizedTest(name = "{0}")
//    @MethodSource("inputFiles")
//    void runReport(String testName,
//                   String testPackId,
//                   TestPackModel.SampleModel sampleModel) {
//        testExtension.runTransformAndAssert(testPackId, sampleModel);
//    }
//
//    private static Stream<Arguments> inputFiles() {
//        return testExtension.getArguments();
//    }
//}
//
