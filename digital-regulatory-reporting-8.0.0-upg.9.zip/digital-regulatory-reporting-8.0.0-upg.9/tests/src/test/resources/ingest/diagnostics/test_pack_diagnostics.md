# Test Pack Diagnostics

| Test Pack | Samples | Completeness |
|:-----------------------------------------------------|:-------:|:-------:|
| exotic | 10 | 111% |
| credit | 14 | 109% |
| fx | 25 | 108% |
| events | 17 | 106% |
| delegated-reporting | 7 | 106% |
| rates | 46 | 104% |
| pre-enrich | 2 | 103% |
| cftc-event-scenarios | 15 | 103% |
| equity | 24 | 103% |
| custom-scenarios | 29 | 103% |
| commodity | 22 | 102% |
