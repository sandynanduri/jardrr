package cdm.ingest.fpml.confirmation.pricequantity.functions;

import fpml.consolidated.asset.*;

import java.util.Objects;
import java.util.Optional;

public class CreateAssetKeyImpl extends CreateAssetKey {

    @Override
    protected String doEvaluate(String keyPrefix, Asset fpmlAsset) {
        int index = Optional.ofNullable(fpmlAsset).map(Objects::hashCode).orElse(2) % 10000;
        return String.format("%s-$%d",
                Optional.ofNullable(keyPrefix).orElse("empty"),
                Math.abs(index));
    }
}
