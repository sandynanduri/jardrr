module.exports = {
  mainSidebar: {
    'Main Menu': ["home", "cdm-overview", "common-domain-model", "product-model", "event-model", "legal-agreements", "process-model", "reference-data-model", "namespace", "serialization", "use-cases", "eligible-collateral-representation", "standardized-functions", "repurchase-agreement-representation", "securities-lending", "pre-trade-processing", "cdm-java-distribution", "dev-guidelines", "download", "cdm-resources", "cdm-videos", "get-involved", "CDM-Contribution-Review-WG", "CDM-Collateral-WG", "CDM-Steering-WG", "CDM-Tokenized-Assets-WG", "CDM-Physical-Risk-WG", "CDM-Technology-Architecture-WG", "CDM-Derivatives-WG"]
  },
}
